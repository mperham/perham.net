ChaNinja Style RC3.5


THEME INSTALLATION

1) If you haven't done so already, then download and run latest StyleXP from www.tgtsoft.com
2) If you are using any of the previous "ChaNinja" themes currently, then Apply another theme e.g. default Windows XP theme. (This is to ensure that the new shellstyle.dll can be overwritten.)
3) Unzip "ChaNinja.theme" file and the entire "ChaNinja" folder to your %Windir%\Resources\Themes folder. 

   If you're not sure where your Windows is installed, go to Command Prompt and enter;
   "echo %Windir%\Resources\Themes" to get folder name.

4) Unzip and install the font DUNGEON.TTF from %Windir%\Resources\Themes\ChaNinja\Fonts (drag and drop into "Fonts" folder found in %Windir%\Fonts folder or via Control Panel [switch to classic view])
5) Select 'ChaNinja' from the Themes tab in Display Properties.
6) Press Apply


LOGONUI INSTALLATION

(1) Depending on your screen resolution, copy the LogonUI.exe from the appropriate folder in %Windir%\Resources\Themes\ChaNinja\LogonUI to your %windir%system32\ folder
(2) You should get 2 "Windows File Protection" errors, answer "Cancel" for the first message and "Yes" for the second.


CURSORS INSTALLATION

1) Goto %Windir%\Resources\Themes\ChaNinja\Cursors\ folder
2) Right-Click on "ChaNinja.inf" file and click "Install" from context menu.
3) Goto Control Panel and select "Mouse" (accessible via "Printers and Other Hardware" if in Category View).
4) Click on "Pointers" tab and select the "ChaNinja" Scheme.
5) Apply.

*** To use the alternative text cursor follow the above steps using "Simple I-Beam.inf" in Step (2) ***


ICONS INSTALLATION

1) Goto %Windir%\Resources\Themes\ChaNinja\Icons\Installer\
2) Run "Iphile.exe" by double-clicking
3) Click on "Open Scheme" button (First icon on toolbar) and select "Open"
4) Double-click on "ChaNinja-Icons.phl"
5) Click "Apply" button on bottom-right
6) You may have to Log out and in again to see new icons.

*** To restore the default icons, do above steps except double-click on "Default-Icons.phl" in step (4) instead. ***

To assign the icons to folders "My Music", "My Movies", "My Pictures";

(1) Run Iphile
(2) Select "Desktop Icons" from the combo box in the toolbar
(3) Click on "My Folders" in the middle pane
(4) Double-click "Add Folder" on the right-side pane
(5) Browse to the correct folder and click "Ok"
(6) Double-click on the folder you just added on the right-side pane
(7) Click "Browse" in the "Change Icon" screen and navigate to %Windir%\Resources\Themes\ChaNinja\Icons
(8) Double-click on the corresponding .ico file
(9) Do this for all 3 folders and click "Apply" on bottom right


WINAMP SKIN INSTALLATION (Get from release RC2.1)

1) Goto %Windir%\Resources\Themes\ChaNinja\Winamp Skin\ folder
2) Double click the "ChaNinjaAmp.wsz" file


SHELL32.DLL PATCH INSTALLATION

The Shell32_Patch will change your system shell32.dll so that the Copy / Move / Recycle Bin animations, IE throbber and "Please wait" screen so that it will match the "ChaNinja" theme. It is safe and reversible.

*** This patch only works with English versions of Windows XP Professional" ***

*** Be sure to read the Troubleshooting section if the patch didn't work AND you have English XP


1) Copy "Shell32_Patch.exe" from %Windir%\Resources\Themes\ChaNinja\Patches\Shell32.dll\ folder to %windir%system32\ folder.
2) Double-Click "Shell32_Patch.exe"   
   ***There will probably be a large pause before the Patcher window pops up (wait at least 5 mins), some noise may eminate from your speakers too...be patient and Double click only once***
3) Click "Start" to execute the patch
4) You should get 2 "Windows File Protection" message boxes (twice each)...
The first "Windows File Protection" message box will ask you to insert your XP CD
    - click "Cancel"
The next one will ask for confirmation to keep the "unrecognized file versions" 
    - click Yes.
5) Reboot

***To test out the animations try copying and moving a few large files (100MB+) ***


SHELL32.DLLs FOR OTHER LANGUAGE VERSIONS OF WINDOWS XP

International users must follow these instructions to modify your shell32, msgina and shdocvw dlls. Its not that complicated so try give it a go.

(1) Download the resource hacker "Restorator from www.bome.com/Restorator
(2) Run it, the pane on the left shows what resources are in the dll, the pane on the bottom-right shows the folder that holds the resources that you will need to work with and the pane on the top-right is a preview of the resource.

*** I will use shell32.dll to explain, but the same methods apply for the msgina.dll and shdocvw.dll files ***

(3) Using Explorer, drag and drop your shell32.dll from %Windir%\System32\ to the left pane in Restorator
(4) Expand shell32.dll in the left pane to see the resources categorized in folders by type (you will be working with AVI, Bitmap and Icon types)
(5) On the bottom pane, navigate to %Windir%\Resources\Themes\ChaNinja\Patches\Shell32.dll\Resources 
(6) Expand the AVI folder in the left pane
(7) Where there are corresponding resources in both the left-side pane and bottom-right pane (i.e. if there is an .avi file in the bottom-right pane with the same filename as a numbered AVI on the left-side pane) then right-click on the resource on the left pane and select 'Assign to "(number).avi"' from the context menu.
(8) Do this for all the AVI files as well as the Bitmaps and Icons (don't forget to navigate to the appropriate folder in the bottom-right pane)
(9) Save the file ("File > Save As" or disk icon on the toolbar), specify the name as shell32.dll in your  %windir%system32\ NOT as the default shell321.dll (Restorator will make a backup of the original shell32.dll by default)
(10) You should get the 2 "Windows File Protection" messages, answer "cancel" for the first and "Yes" for the second.
(11) Do this for msgina.dll and shdocvw.dll
(12) Reboot


TROUBLESHOOTING

If you failed to see any changes and didn't get any "File Protection" errors then do the following before applying the patch ;

1) Make sure the Windows XP Installation CD is NOT in your CD-ROM drive.
2) In Explorer, goto "Tools > Folder Options... > View"
   Under "Hidden files and folders" select "Show hidden files and folders"
   Uncheck "Hide protected operating system files"
3) Goto %Windir%\System32\dllcache\ (now unhidden)
   Delete shell32.dll
4) If your WIndows XP Install files are stored locally then rename the file ...i386\SHELL32.DL_ to SHELL32BAK.DL_, (you can simply rename the file back after applying the patch.)
5) Repeat steps (1) to (5) above to apply the patch.
6) If it still does not work then try this ;
   Copy the file %Windir%\System32\shell32.dll and the Shell32_Patch.exe to your Desktop
   Run the patch by double-clicking the Shell32_Patch.exe
   Once its complete copy the shell32.dll from your Desktop to the %Windir%\System32\ folder.
   You should then get the 2 "File Protection" messages.
   Reboot
7) Still fails? Follow the method using Restorator given above.


DLL RESTORATION

To undo the above process repeat all the shell32 patch steps using "Shell32_Restore.exe", "Msgina.dll_Restore.exe" or "Shdocvw.dll_Restore.exe" this time.


MSGINA.DLL & SHDOCVW.DLL PATCH INSTALLATION

All the Installation / Restoration steps and Troubleshooting instructions are the same for these as the Shell32.dll.

THINGS TO COME

1) Dedicated web page for the style and other stuff by me. I'll announce the URL soon on the www.themexp.org's comment section for this release. 

It'll include 
 - All previous releases of the Style + latest betas
 - Bootscreen
 - LoginUIs
 - High res Wallpapers
 - Screensavers
 - Cursors
 - Icons
 - Sounds
 - .dll hacks
 - Various tool hacks e.g. shell audioplayer
 - Tips'n tricks
 - Feedback submissions
 - Lots more...all categorised too!
2) The next release at www.themexp.org will be huge cos I'm gonna include everything. You've been warned!

CREDITS:
	
	Whackboy - Shellstyle.dll
	Filip Frys <lasic@irc.pl> - Dungeon.ttf mod
	All those that sent feedback! Shot!





AND NOW A CHANCE FOR ALL OF YOU TO TRY SOMETHING DIFFERENT;

The postal service. If you like this theme and want to catalyze progress, then please send some postal orders or cash (notes) to :

	ChaNinja
	15 Kingston Court
	Chapel Rd.
	Rosebank
	7700
	Cape Town
	South Africa


If thats too much for you, then you can always send me a donation via www.paypal.com to chaninja@yahoo.co.uk

Don't make me send Tetsuo over there to convince you! |;|


ChaNinja
