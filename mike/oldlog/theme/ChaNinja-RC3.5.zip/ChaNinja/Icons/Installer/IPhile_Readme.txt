Icon Phile v.2.01 ReadMe  - June 16, 2001
============================================
By: Tal Sella & Dor Naveh

Send Comments to: Iconphile@hotmail.com
http://www.virtualplastic.net/scrow/

1. About
2. Version History
3. Installation
4  Features
5. The Basics
6. Troubleshooting
7. Disclaimer


About
=====

Icon Phile was inspired by the need for a faster and simpler interface for customizing File Type icons in Windows.  Icon Phile offers a simple view of all file types pertaining to the user, which can be changed by a simple click of the mouse.  
After receiving countless Emails from people having trouble with the installation of file type icon: some of them not knowing how to do it, and some demanding an easier way, we decided to ease on ourselves and others and write Icon Phile.  We hope Icon Phile offers a solution to these problems.
But wait, there's more...The first few betas got great feedback.  People especially appreciated the easy drag n'drop interface. It proved to be very simple and fast, an asset to any "power" user, and so it was decided to include desktop icons. 
For program updates and more icons for your system check Scrow's Icons at http://members.xoom.com/scrows .


Version History
===============


2.02  -Memory Bug and others fixxed
        + Command to register new extensions

2.01  - win98 bugs fixed
        - folderbar bugs fixed

2.00  + New Icons
        + DragDrop Edit Groups Interface

1.89  +  FileBar added

1.87 (Internal Build)
      + Iphile2000 combined w/ Iphile98
      + Toggle Desktop Icon Style
      - Desktop Label Transparency fixed for Win2000
      - Cursor Animation bug fixed
      - "'' is not a valid integer" bug killed - I hope.......

1.8   Bug FIxes
      Add Imports to Browse Library	
      First Iphile 2000 version released. 

1.7   >>Last Iphile 98 version.<<
      +  Ability to customize cursors (Desktop Icons/Cursors) + animated cursor preview
      +  MAke Desktop Icons Background Transparent 
      +  Change Desktop Icons text color
      -  Fixed error on DblClk of .phl 
      -  Menus use system colors instead of defaulting to grey

1.67  + 'Other Icons' group created on load of themes with icons not in any group
      + Import command - Iphile attempts to create a theme based on the icons's names.
                         Checked to work with the common theme formats avalable on the web
			 and with many icon packages that don't include theme files.	

1.6   + Some visual improvements
      + Scheme/Theme Browser
      + Comparison View (Before/After)
      + Icons in schemes split into groups with the ability to load/not load any group
      + Option to copy all applied icons to a certain folder
      + Tools Menu: -Rebuild Icon Cache
              -Icon Color Depth
              -Display First Icon in file for certain extensions (Toggle)
              -Display Shortcut/Sharing Overlay
              -Restore Default Win Icons
      - Change any drive icon
      - Added Icons: Briefcase, Internet Explorer, MS Ftp Folder
      - Iphile Windowshade on titlebar doubleblclick
      - Bucket-o-Bugfixes
	
1.56  + "Compare Icons" toggle
      + View all icons in Iphile
      + Option to only save changed(with +)/selected icons rather than all icons
      + Option to save icons as seperate .ico's along with the scheme
      + Add folders to "My Folders" with Drag N'Drop (Drag to "Add Folder")
      - "Edit Groups" bug fixed
      - Rearanged Save Menu
      - Fixed bug which may have reporeted inacurate icons paths

1.5   + Ability to customize individual non-system folders ("My Folders")
      - Faster scheme saving

1.4   - Handled various problems generated when manualy editing Iphile's files
      + Progress Bar
      + New Icon for IconPhile schemes (*.phl)
      + Option to restore Windows' Default Desktop Icons
      + Ability to change individual hard drive icons
      - View All Changes command moved to toolbar
      - Icon Focus Bug fixed
      + Icons saved in Schemes
      + Option to manually enter icon path 	

1.2   + Smaller Executable Size
      + FULL scheme save 
      + Ability to change more desktop Icons: Folders, Network stuff
      + Organized the "Desktop Icons" into sub-groups, less clutter 
      + Added "Mixed Icons" view mode
      + Window Position is saved
      + Added ability to change Audio CD icon
      + Added "New Group" option to the Groups Editor in an effort to make it simpler
	
1.1   + Added Start Menu icons to the Desktop Icons group
      + Ability to register new extensions and change their icons
      - bug fixes, handling

1.00  + Groooooy Menus + an option to revive the regular ones
      + Pressing Del restores the selected icon
      + Settings are saved
      + "Apply Phile" added to Explorer's context menu for .phl's
      + Option to display Icon's Path
      + Implemented the standard windows keyboard shortcuts, see tooltips
      - Fixed a small bug in the icon representation
      + Added option to see "File Type"s instead of extensions as icon captions (Full Captions)
      - Save dialog's path does not default to IPhile's dir every time
      - missing icons are handled better
      - MultiSelecting Icons and then dragging will change all selected icons, not just the drop
        target
      + Main window uses full area move	

0.98b - Works on NT
      - Fixed Empty Recycle Bin Related bugs
      - Looks Better in LargeFonts mode
      - Default Icon Groups reorganized and expanded
      - No more scroll spasms in the ListView
      - "About" is even more "exciting"
      - All Desktop Icon changes are immediately visible, without the need to refresh the cache
      + !!Small Icons View Mode Added!!
      + Cancel button added to "Apply Changes?" dialog

0.98a - Better IconCache Refresh, system's icons are changed immediately on Apply.
      - Previewed icons are shown correctly (ie. documents with little notepad icon)
      + Opened & Dragged Schemes are added to the Recent Docs
      - Fixed bug in scheme application procedure
      + Added 'View Change' Group - - Shows all changes made, useful when applying schemes
      + "Load Scheme" Popup is refreshed, .phl's which are moved to IconPhile's folder will appear

0.98 + First Beta Release


Installation
===========
Icon Phile is one of the most unintrusive programs around.  To install, simply copy the Iphile.exe into any folder on your computer.  To uninstall, just delete that folder.  Its that simple.  If you would like to restore your system's icons to their pre-"Icon Phile" state, you should save an icon scheme for your system before making changes.  Should you decide to uninstall just apply that scheme.


Features
========

- supports file types, desktop icons drive and folder icons
- quick drag and drop interface for changing icons
- change a number of icons at once (use multiselect)
- register new extensions
- undo changes
- change icons for files with different extensions that are all of the same "File Type"
- see only the file types you wanna see
- save icon schemes, which include file icons


The Basics
==========

On startup, Icon Phile loads the preset default groups, which can be changed at any time.
The Main Window includes the following:

#Features - The most important feature in Icon Phile is its drag n' drop support.  Just drag any file that has icons in it to one of the items in Icon Phile.  If the file's extension is .ico, the item's icon will change to that .ico, if its an exe, dll or icl, a dialog will pop up prompting you to choose one of the icons in the file which will become the new item's icon.  I say "item" for lack of a better name, but what I mean is any of the icons in Icon Phile representing a file type or desktop icon. kay?

Setting the Icon Phile window to "Always on Top" is also useful when giving your system a complete icon overhaul (dragging lots of different icons to Icon PHile).  To set Icon PHile always on top right click the title bar and select "Always on Top" from the system menu.  Just click it again to make Icon Phile normal again.  The Main Window also uses full-area move: Moving the window is not exclusive to the title bar but can be accomplished by dragging any point on the form.  Again, just a little feature to help you throw IconPhile to the side while browsing your drive for Icons to drag to it. 

#Load & Save Buttons - Icon Phile supports icon schemes. Change all the icons displayed in Icon Phile to the ones you want to include in the scheme and press save.  All icons shown in IconPHile will be saved in the scheme.  The scheme is saved as a file with a .phl extension.  
+ Load Button
To load one of these schemes either use the Load button in "Icon Phile" or double click the scheme in windows' explorer.  If you're already in explorer and see a scheme you want to bestow upon your system, you can immediately apply it by left-clicking and selecting "Apply Phile" from the context menu.  Lo' and behold your computer will don its new glistening stockings.    
+Save Button
\ Save All - Save all the icons in Iphile
\ Save Changes - Only save changed icons, icons with a "+" next to them.
\ Save Selected - Only save selected Icons.
\ Icons SubMenu - The SubMenu offers 3 methods of scheme saving. The first method ("Don't Touch") was IconPhile's default up until version 1.2.  The scheme generated is a relatively small file which includes textual information relating to the icon's locations.  The second method ("Save in Scheme"), generates an Icon Library which holds copies of all your system's icons.  This scheme's size is greatly larger, depending on the amount of icons saved, their metrics, color depth etc..  These schemes are much more portable and can be easily transferred to other computers.  The third method ("Save Seperate") is a combination of both previous methods.  The scheme and all it's icons are saved in one directory.  The icons are saved as standard .ico files.
I my opinion the second method of saving, with icons, is best.  Since the icons are embedded in the file they are not dependant on any external files.  These may include program files or libraries that you may delete someday.  The scheme's size may be a little more but it still is peanuts.

#Undo Button - When you make changes in to your system's icons, apply them and they look butt-ugly, don't fret just click the undo button (before exiting Icon Phile, duh..), click apply, and you've got your old icons back.  Simply stated, the undo button restores your system's icons to the way they were prior to the current Icon Phile Session (only if you press Apply though).

#View Change Button - Pops up a menu with a list of options for the Icon Preview Window.  
+Icon Style - Switches between 3 Icon Viewing Styles: Large, Small or Mixed icons allowing a more accurate perception of your icons.  An advantage in viewing icons in Small mode is that more icons fit in the window, which makes it eases on the Drag n'Drop process.  On the other hand, Mixed mode presents the icon in both Large and Small sizes simultaneously.  Choose the mode that most suits your needs!!
+Small/Full Captions - IconPhile's defaults to Small captions, where the icons' captions are just their file extensions.  Toggling the "Full Captions" mode switches the Icon Captions to their file type descriptions, similar to that in windows' "File Types" dialog.  These two caption types contrast in their lengths; simply put, the Full captions take up more space. Some users may find classification by extension more efficient, while others may regard the Full captions as more informative.  Since Windows tends to hide file extensions and refers to files by their descriptions the latter option may solve extension orientation problems.
+Show/Hide Path - An option for the selected icon's path to be displayed. Icons which are created by windows do not have a tangible path, therefore their path will appear empty.  The path is shown near the bottom of the window.  Double clicking the path will make it editable allowing the user to manually type a different icon's path.  This feature is only good for Super Advanced Computer Power User Gurus.
+Regular Menus - You just can't stand Iphile groooovy menus??  Do they annoy you to death??  Calm down and wipe that sweat off your brow, this toggle will return your plain vanilla default menus.

#Filtered Views Button - Allows you to filter the icon shown in the main window.
+ View Changes - Simply lets you preview all your changes before applying them.
+ View All - Shows all the icons in Iphile.
+ Compare Icons - Toggle icon comparison in themes.  When you open a theme a "+" appears next to the icons changed by the theme.  With "Compare Icons" disabled the "+" will appear next to all icons in the theme.  With it disabled, Iphile will graphicaly compare the theme's icon with the current icon to check if it is really different.  When editing themes I recommend disabling this option so tat you can see the icons in the theme. 

#Group List Box - The file Types in the system are split into groups, ex. "Picture Files, Sound Files, etc..". The names of the groups appear in the DropDown List. On clicking a group name, the icons of the associated extensions will appear in the main icon preview window.  There is one "special" group which is not configurable, "Desktop Icons".  "Desktop Icons" is a group consisting of system icons, ie. MyComputer, Folders, Drives... On entering this group 6 buttons will appear on the left.  Every button accesses a different category of "Desktop Icons".  
All these categories are predefined except "My Folders".  This category lets you customize the icons for single folders.  You can add any folder on your hard drive to this category, ie. C:\Windows, C:\Quake.. There are two ways to add a folder: 1.  DoubleClick the "Add Folder" icon and select the folder you want to add in the "Select Folder" dialog, 2.  Drag the folder to the "Add Folder" icon.  Once the folder is added it will appear in category and you will be able to customize its icon in the standard Iphile fashion.  Clicking "Remove Folder" in the folders' popup menu will reomve the folder from the group.

#Icon Preview Window - This window shows previews of the icons associated with their specified file extension as they will appear in the windows Explorer. Double Click any of the icons to change it.  The Standard Windows Icon Browse dialog will pop up, enabling the selection of a new icon.  The icon can be a *.ico or part of any *.dll,*.exe. etc..  You can also drag an icon file (ico,exe,dll,icl) from windows explorer to any of the icons displayed in this window to quickly change it.
Important! One of Icon Phile's key features is the ability to change the icons for a number of different file extensions at once. For example, Changing all Picture files to a single picture icon. In order to do this, select the icons you want to change in the Icon Preview Window, (by multi-selecting with the rectangle, or pressing the Ctrl key and clicking on the icons).  Now, right click anywhere in the window, select "Change Icon" in the popup menu, and browse for the chosen icon. It is also possible to drag any one of the supported files to Iphile, when multiple icons are selected, and the all will change. For more icons check Scrow's Icons: at http://members.xoom.com/scrows .
If after changing an icon, you don't like the new one, right click the icon, select "Restore Icon" for the popup menu and the icon will return to its previous state.  Unlike the Undo button, this option restores the last icon applied and not the icon used prior to this session of Icon Phile.
The last item in the Pop Menu, "Load Scheme" offers a shortcut to loading .phl schemes.  Any scheme saved in Iphile's program directory will appear on this list of schemes.  Loading a scheme in this fashion is equivalent to Loading via the Load Button.
The absolutely last item on this menu, visible only in the "Desktop Icons" category is "Default Icon".  This will restore windows' default icon for the selected item.  I'm talking about the primal icon that ships with windows, the one you were faced with when you just installed windows.....I shudder at the thought.

#Edit Groups - Clicking on the Edit Groups button on the main window will open the "Groups Editor" Window.  This window lets you manage your groups. Note that the "Desktop Icons" group is not configurable and will not be listed in the Groups Editor. There are two list boxes in this window, the right one showing all file extensions available on the system, the left one showing all extensions in the currently selected group.  The dropdown list offers access to existing groups- you can remove or add extensions to these groups by using the arrow buttons between the listboxes.  Select a group and click "Delete" to delete the group.  Make a new group by selecting "[New Group]" in the dropdown , writing it's name in the "Name" caption ,adding a few file extensions to it, and then clicking the "ADD" button.  In adding extensions you are not restricted to the two arrow buttons, you can also drag and drop between the listboxes or double click the extensions.
Right-Clicking the Right-Most Listbox will popup a menu with the item: "New...".  This option is geared more towards expert users.  Basically, it allows you to register new extensions on your system.  In the following dialog you will be asked to enter the extension ( the part of the filename succeeding the dot).  After confirming the request, the new extension will appear in the right listbox, allowing you to add it to a group and change its icon.  Why is this useful??  I have found situations where I wanted to change the icon of an unregistered extension.  Previously, in order to do this I would have to associate the extension with an application. In some cases this is pointless and quite a hassle.  For example, Swap Files which bare the '.swp' extension.  I own no program that can open these files, and therefore cannot associate it with one.  I just want to change the icon, and that's where this option comes in handy.  
After making all the requested changes click "Save" to save them and return to the main window or "Cancel" to return without saving.

#Apply Button - The Apply button located at the bottom of the main form applies the changes made to the icons immediately.  You can check how your computer "wears" the new icons, and if it's not to your taste just click on the undo button before leaving.  While writing the program we found two ways to rebuild the system's Icon Cache (a necessary step in the icon customizing process).  The preferred way is the one used when clicking the Apply button.  This method only refreshes the icons which were changed and is much lighter on the system.  The second method refreshes all the icons used by the system and is naturally heavier on resources.  The second method should be used when the first fails.  In other words, if you change your icons, click Apply, and see that nothing happens use the second method.  This is done simply by making the changes in Icon PHile and holding down the CTRL button on clicking Apply.  Some users may experience incorrect icons in their QuickLaunch toolbars, after using this method..Don't worry, when you restart windows they'll return to normal.

#Close Button - Closes Icon Phile, not much to it.  Lets you leave the program without applying changes.  If changes were made and not applied, you'll be prompted.

Troubleshooting
===============
Problem: I just ran IconPhile and some of the Desktop Icons are wrong.
Solution: Yeah, I know, live with it for the meanwhile, we'll get it fixed in the next version.  The icons are only displayed wrong but if you change them, the changes will be applied.  After the first time you change the icon, it should always show up correctly.

Problem: I am head over heels in love with my local television station's weatherman.  He is tall, dark, handsome, witty, and an excellent fisherman.  He appears in my dream, robed in a cashmere toga and floating on a pink cloud.  The mere thought of him makes me go ummm.......  
Solution: Buy a yellow raincoat, sunglasses, and moccasins.  Wear them at all times.


DISCLAIMER OF WARRANTY 
=======================
THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE AUTHOR FURTHER DISCLAIMS ALL WARRANTIES, INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.  THE ENTIRE RISK ARISING OUT OF THE USE OR PERFORMANCE OF THE PRODUCT AND DOCUMENTATION REMAINS WITH RECIPIENT. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CONSEQUENTIAL, INCIDENTAL, DIRECT, INDIRECT, SPECIAL, PUNITIVE, OR OTHER DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING OUT OF THIS AGREEMENT OR THE USE OF OR INABILITY TO USE THE PRODUCT, EVEN IF THE AUTHOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 

..and on the seventh day he retired.
