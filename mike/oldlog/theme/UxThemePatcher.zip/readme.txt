Patcher for UXTHEME.DLL.

WARNING: User assumes all responsibility for running the patch program
and patching the uxtheme.dll file. User agress to hold harmless TGT Soft
LLC.  If you do not agree to these terms, please do not patch the file.

To patch UXTHEME.DLL you must follow these directions.  If it does not
work, please do not email us.  We tried.

First, you must have administrator privileges.
Second, you must understand how to rename and copy files.
Third, you must understand where your system directory is and how to
navigate there (although the patcher will tell you where it is).

If you update your Windows(r) XP operating system, the patch may become
invalid.

Ready?  Here are the instructions.

1) Run the uxthemepatcher.exe.  This program will produce a "uxtheme.pat"
   file in your system32 directory.  If this program fails, DO NOT
   CONTINUE.

2) After you have successfully run uxthemepatcher.exe, a message box
   will tell you where the uxtheme.pat file is.  If your system directory
   is c:\windows\system32 -- the uxtheme.pat file will be there.  If it is
   c:\winnt\system32 -- the uxtheme.pat file will be there.  And so on.
   Make a mental note of where the .pat file is.

3) Assuming your system directory is c:\windows\system32 go into the
   directory c:\windows\system32\dllcache.  This directory may be hidden.
   If it is, you need to unhide it to see it, or use the command prompt.

4) Rename the uxtheme.dll file in dllcache to uxtheme.bak (or some other
   name).

5) Rename any uxtheme.dl_ or uxtheme.dll that might be found in other
   locations on your system such as c:\i386 or the place where you
   installed Windows(r) XP from.  

6) Make sure you have NO CDs in your system (especially the Windows(r) XP
   install CD!).

7) Assuming your system directory is c:\windows\system32 go into the
   directory c:\windows\system32.  Rename uxtheme.dll to uxtheme.bak or
   some other name.  Copy uxtheme.pat to uxtheme.dll.

8) You might get a warning from Windows System File Protection.  You need
   to answer the two questions properly, and on your own volition to
   ensure that the uxtheme.dll file is not replaced with the original.

9) If all goes well, the uxtheme.dll will be the same DATE and TIME as
   the uxtheme.pat.  If this is the case, REBOOT.  Do not logoff, you need
   a full reboot.

Hope this works.  If it does not, you can always try the Style XP trial
for 30 days.

http://www.tgtsoft.com



