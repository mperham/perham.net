// Strings.h - contains all language-dependent strings in AppBar

#ifdef GERMAN
	#define SELECT_MENU                     "Bitte zuerst ein Men$B�(Jausw$BgI(Jlen."
	#define SELECT_ITEM                     "Bitte zuerst einen Eintrag
 ausw$BgI(Jlen."
	#define OLD_DATAFILE_FORMAT             "Profildatei im alten Datenformat
 gefunden.\nBitte l$B�T(Jchen Sie sie und\n erstellen Sie eine neue."
	#define ERROR_READING_MENUS             "Fehler beim Lesen des Men$B�T(J: %d
 Programm: %d\naus Profildatei: %s.\nBitte l$B�T(Jchen Sie die Datei
 und\nstarten Sie Appbar erneut."
	#define ERROR_LINK                      "Fehler beim Starten einer
 Verkn$B�Q(Jfung."
	#define FILE_NOT_FOUND                  "Datei nicht gefunden:\n%s"
	#define PATH_NOT_FOUND                  "Dateipfad nicht gefunden:\n%s"
	#define OUT_OF_MEM                      "Zu wenig Speicher um das Programm
 zu starten."
	#define DLL_NOT_FOUND                   "Die zum Starten dieses
 Programms\nerforderliche DLL-Datei wurde nicht gefunden."
	#define RETURNED_ERROR                  "ShellExecute f$B�I(Jrte zu folgendem
 Fehlercode: %d"
	#define INVALID_FILENAME                "Fehlender oder falscher
 Dateiname\nbeim Aufruf in der DOS-Kommandozeile."
	#define UNKNOWN_OPTION                  "Unbekannte Option: %s"
	#define ERROR_OPENING_REG               "Fehler beim Zugriff auf die
 Windows-Registrierungsdatei!\nDas Standard-Setup wird benutzt."
	#define OBSOLETE_REG_DATA               "Veraltete
 Registrierungsinformationen gefunden.\nDiese werden mit den Standarddaten
 $B�C(Jerschrieben."
	#define WELCOME_MSG                     "Vielen Dank f$B�S(J die Benutzung von
 AppBar%s%s!\nSollten Sie einen Fehler bemerken, schicken Sie\nbitte eine
 Email an: mperham@cs.cornell.edu!"
	#define ERROR_SAVING_REG                "Beim Sichern der Benutzer-Optionen
 in die\nWindows-Registrierungsdatei trat ein Fehler auf!"
	#define ERROR_OPENING_DATAFILE          "Profildatei %s konnte nicht
 geschrieben werden.\nBitte $B�C(Jerpr$B�G(Jen Sie die Datei."
	#define ERROR_AUTOHIDING                "Fehler beim automatischen
 Verstecken\nder Men$B�M(Jeiste! Ist dort die Task-Leiste?"
	#define ERROR_PLAYING_WAV               "Fehler beim Abspielen einer
 WAV-Datei.\n$B%o(Jberpr$B�G(Jen Sie Pfad und Dateiname."
	#define ERROR_FINDING_MENU              "Das Men$B�(Jkonnte nicht gefunden
 werden!"
	#define ERROR_FINDING_APP               "Das Programm konnte nicht gefunden
 werden!"
	#define FATAL_ERROR                     "Schwerer Fehler in AppBar
 aufgetreten!"
	#define WAV_FILE_TYPES                  "WAV-Dateien\0*.WAV\0"
	#define EXE_FILE_TYPES                 
 "Programm-Dateien\0*.EXE;*.COM;*.BAT;*.PIF;*.LNK\0Alle Dateien\0*.*\0"
	#define FIND_WAV                        "WAV-Datei suchen ..."
	#define FIND_EXE                        "Programm-Datei suchen ..."
	#define ERROR_ENTER_WAVNAME             "Bitte geben Sie den Namen einer
 WAV-Datei ein."
	#define ERROR_AUTOHIDE_NT               "Automatisches Verstecken kann in
 Windows NT 3.x nicht abgeschaltet werden!"
	#define ERROR_NAME_FILENAME             "Sie m$B�T(Jsen einen Namen und
 den\nPfad der Programm-Datei eingeben."
	#define ERROR_MENUNAME                  "Das Men$B�(Jmu$B!,(J einen Namen
 erhalten!"
	#define ERROR_HOTKEY                    "Tastaturk$B�S(Jzel f$B�S(J AppBar konnte
 nicht installiert werden!"
	#define CONFIRM_DELETE                  "Sind Sie sicher, da$B!,(J Sie dieses
 Men$B�(Jund\nalle darin aufgef$B�I(Jrten Eintr$BgH(Je l$B�T(Jchen wollen?"
	#define CONFIRM_DELETE_TITLE    	"Bitte L$B�T(Jchen best$BgU(Jigen."
	#define DEFAULT_NAME                    "Standardname"
#elif JAPANESE
	#define SELECT_MENU						"$B%a%K%e!<$rA*Br$7$F$/$@$5$$(J"
	#define SELECT_ITEM						"$B9`L\$rA*Br$7$F$/$@$5$$(J"
	#define OLD_DATAFILE_FORMAT            
 "$B8E$$7A<0$N%G!<%?%U%!%$%k$,8+$D$+$j$^$7$?!#(J\n$B:o=|$7$F:n@.$7D>$7$F$/$@$5$$!#(J"
	#define ERROR_READING_MENUS            
 "$B%a%K%e!<$NFI$_9~$_$K<:GT$7$^$7$?(J.$B!#(J $B%a%K%e!<(J: %d $B%"%W%j%1!<%7%g%s(J: %d\n$B%G!<%?%U%!%$%k(J:
 %s.\n$B%G!<%?%U%!%$%k$r:o=|$7$F(J AppBar $B$r:F5/F0$7$F$/$@$5$$!#(J"
	#define ERROR_LINK                      "$B%j%s%/%(%i!<$G$9!#(J"
	#define FILE_NOT_FOUND                  "$B%U%!%$%k$,8+$D$+$j$^$;$s!#(J\n%s"
	#define PATH_NOT_FOUND                  "$B%Q%9$,8+$D$+$j$^$;$s(J:\n%s"
	#define OUT_OF_MEM                     
 "$B%"%W%j%1!<%7%g%s$N<B9T$N$?$a$N%a%b%j!<MFNL$,IT==J,$G$9!#(J"
	#define DLL_NOT_FOUND                   "$B$3$N%"%W%j%1!<%7%g%s$N<B9T$KI,MW$J(J
 DLL $B$,8+$D$+$j$^$;$s!#(J"
	#define RETURNED_ERROR                  "ShellExecute API $B$N%j%?!<%s%3!<%I(J:
 %d"
	#define INVALID_FILENAME               
 "$B%3%^%s%I%i%$%s$K;XDj$7$?%U%!%$%kL>$,L58z$G$9!#(J"
	#define UNKNOWN_OPTION                  "$B;XDj$7$?%*%W%7%g%s$O$"$j$^$;$s(J:
 %s"
	#define ERROR_OPENING_REG              
 "$B%l%8%9%H%j%-!<$,$,3+$1$^$;$s!#(J\n$B%G%U%)%k%HCM$r;HMQ$7$^$9!#(J"
	#define OBSOLETE_REG_DATA              
 "$B5l<0$N%l%8%9%H%j%G!<%?$,8+$D$+$j$^$7$?!#(J\n$B:o=|$7$F!"%G%U%)%k%HCM$r@_Dj$7$^$9!#(J"
	#define WELCOME_MSG                     "Thanks for Trying
 AppBar%s%s!\n$B%P%0$rH/8+$7$?>l9g$O!"2<5-$N%"%I%l%9$^$G%P%0%l%]!<%H$r$h$m$7$/$*4j$$$7$^$9!#(J\nthem
 to mperham@cs.cornell.edu!"
	#define ERROR_SAVING_REG               
 "$B%l%8%9%H%j$N%;!<%V$K<:GT$7$^$7$?!#(J"
	#define ERROR_OPENING_DATAFILE  	"$B%G!<%?%U%!%$%k(J  %s
 $B$,3+$1$^$;$s!#(J\n$B%U%!%$%k$r3NG'$7$F$/$@$5$$!#(J"
	#define ERROR_AUTOHIDING                "AppBar $B$N(J Auto Hide
 $B$N@_Dj$K<:GT$7$^$7$?!#(J"
	#define ERROR_PLAYING_WAV               "WAV
 $B%U%!%$%k$,:F@8$G$-$^$;$s!#(J\n$B%Q%9!"%U%!%$%kL>$r%A%'%C%/$7$F$/$@$5$$!#(J"
	#define ERROR_FINDING_MENU             
 "$B%j%9%H$NCf$N%a%K%e!<$,8+$D$+$j$^$;$s!#(J"
	#define ERROR_FINDING_APP              
 "$B%j%9%H$NCf$N%"%W%j%1!<%7%g%s$,8+$D$+$j$^$;$s!#(J"
	#define FATAL_ERROR                    
 "$BCWL?E*$J%(%i!<$,H/@8$7$^$7$?!#(J\n$B%"%W%j%1!<%7%g%s$r=*N;$7$^$9!#(J"
	#define WAV_FILE_TYPES                  "WAV $B%U%!%$%k(J\0*.WAV\0"
	#define EXE_FILE_TYPES                 
 "$B<B9T2DG=%U%!%$%k(J\0*.EXE;*.COM;*.BAT;*.PIF\0$B$9$Y$F$N%U%!%$%k(J\0*.*\0"
	#define FIND_WAV                        "WAV$B%U%!%$%k$NA*Br(J..."
	#define FIND_EXE                        "$B<B9T%U%!%$%k$NA*Br(J..."
	#define ERROR_ENTER_WAVNAME             "WAV
 $B%U%!%$%kL>$rF~NO$7$F$/$@$5$$!#(J"
	#define ERROR_AUTOHIDE_NT               "Windows NT v3 ! $B$G$O(J AutoHide
 $B$OJQ99$G$-$^$;$s!#(J"
	#define ERROR_NAME_FILENAME            
 "$BEPO?$9$k%"%W%j%1!<%7%g%s$K$OI,$:L>A0$,I,MW$G$9!#(J"
	#define ERROR_MENUNAME                 
 "$BEPO?$9$k%a%K%e!<$K$OI,$:L>A0$,I,MW$G$9!#(J"
	#define ERROR_HOTKEY                    "AppBar
 $B$r%[%C%H%-!<$K3d$jEv$F$i$l$^$;$s$G$7$?!#(J"
	#define CONFIRM_DELETE                 
 "$B$3$N%a%K%e!<$H4XO"$9$k%"%W%j%1!<%7%g%s$r:o=|$7$F$b$h$m$7$$$G$9$+!)(J"
	#define CONFIRM_DELETE_TITLE    	"$B:o=|$N3NG'(J"
	#define DEFAULT_NAME                    "Default Name"
#else
	#define SELECT_MENU                     "Please select a menu first."
	#define SELECT_ITEM                     "Please select an item first"
	#define OLD_DATAFILE_FORMAT             "Old datafile format found.\nDelete
 it and recreate it."
	#define ERROR_READING_MENUS             "Error reading menu: %d app:
 %d\nfrom data file: %s. Please\ndelete it and restart AppBar."
	#define ERROR_LINK                      "Error executing link."
	#define FILE_NOT_FOUND                  "File not found:\n%s"
	#define PATH_NOT_FOUND                  "Path not found:\n%s"
	#define OUT_OF_MEM                      "Insufficient memory to start
 application."
	#define DLL_NOT_FOUND                   "A required DLL necessary to
 start\nthis application was not found."
	#define RETURNED_ERROR                  "ShellExecute returned error code:
 %d"
	#define INVALID_FILENAME                "Missing or invalid filename on
 command line!"
	#define UNKNOWN_OPTION                  "Unknown option: %s"
	#define ERROR_OPENING_REG               "Error opening Registry key!\nUsing
 default setup."
	#define OBSOLETE_REG_DATA               "Obsolete registry data
 found.\nDeleting it and installing default data."
	#define WELCOME_MSG                     "Thanks for trying AppBar%s%s!\nIf
 you find any bugs, please report\nthem to mperham@cs.cornell.edu!"
	#define ERROR_SAVING_REG                "Error saving user options to
 Registry!"
	#define ERROR_OPENING_DATAFILE  	"Could not open %s for write.\nPlease
 check the file."
	#define ERROR_AUTOHIDING                "Error autohiding!  Is\nthe Start
 Menu there?"
	#define ERROR_PLAYING_WAV               "Error playing WAV file.\nCheck
 path and filename."
	#define ERROR_FINDING_MENU              "Menu not found in linked list!"
	#define ERROR_FINDING_APP               "Application not found in linked
 list!"
	#define FATAL_ERROR                     "Fatal AppBar Error"
	#define WAV_FILE_TYPES                  "WAV Files\0*.WAV\0"
	#define EXE_FILE_TYPES                 
 "Executables\0*.EXE;*.COM;*.BAT;*.PIF\0All Files\0*.*\0"
	#define FIND_WAV                        "Find WAV File..."
	#define FIND_EXE                        "Find Executable..."
	#define ERROR_ENTER_WAVNAME             "Please enter a WAV filename."
	#define ERROR_AUTOHIDE_NT               "AutoHide must always be on in
 Windows NT v3!"
	#define ERROR_NAME_FILENAME             "The application must have a
 name\nand associated filename."
	#define ERROR_MENUNAME                  "The menu must have a name!"
	#define ERROR_HOTKEY                    "Could not assign hotkey for
 AppBar!"
	#define CONFIRM_DELETE                  "Are you sure you want to
 delete\nthis menu and all related apps?"
	#define CONFIRM_DELETE_TITLE    	"Confirm Deletion"
	#define DEFAULT_NAME                    "Default Name"
#endif
