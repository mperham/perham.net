// Non-C++ code

#include "appbar.h"
#include "globals.h"

void killmenu(menu_struct *menu)
{
	app_struct *app, *front;

	if (!menu)                  // Null menu
		return;
	app = menu->nextapp;
	if  (!app) {                // Menu w/o applications (?)
		delete menu;
		return;
	}
	front = app->nextapp;
	while (front!=NULL) {
		delete app;
		app = front;
		front = front->nextapp;
	}
	delete app;
	delete menu;
}

// Updates app linked list and deletes app node
// DOES NOT update menu->nextapp (calling code should)

void killapp(app_struct * app)
{
	if (!app)
		return;
	delete app;
}

// Finds menu by name in list

menu_struct * find_menu(char * menu_sel)
{
	menu_struct * menu;

	for (menu = glob_menu; menu != NULL; menu = menu->nextmenu)
		if (!strcmp(menu->menuname,menu_sel))
			return menu;
	ab_message(ERROR_FINDING_MENU, ab.abwin->GetSafeHwnd());   
	return NULL;
}

app_struct * find_app(app_struct * apps, char * app_sel)
{
	app_struct * app;

	if (!strcmp(app_sel, SEPARATOR_STRING))
		return NULL;
	for (app = apps; app != NULL; app = app->nextapp)
		if (!strcmp(app_sel,app->appname))
			return app;
	ab_message(ERROR_FINDING_APP, ab.abwin->GetSafeHwnd());
	return NULL;
}

//////////////////////////////////////////////////
// Print error message and exit program

void error(char *err_msg)
{
	::MessageBox(NULL, err_msg, FATAL_ERROR, MB_OK | MB_ICONSTOP);
	_fcloseall();
	ab.ExitAppBar(TRUE);
}

void DoBrowse(int type, CDialog* pParent)
{ 
	OPENFILENAME ofn;
	char szFile[80];
	
	strcpy(szFile,""); 

	ofn.lStructSize       = sizeof(OPENFILENAME); 
	ofn.hwndOwner         = pParent->m_hWnd; 
	ofn.hInstance         = NULL; 
	ofn.lpstrFilter       = (type ? WAV_FILE_TYPES : EXE_FILE_TYPES); 
	ofn.lpstrCustomFilter = NULL; 
	ofn.nMaxCustFilter    = 0L; 
	ofn.nFilterIndex      = 1L; 
	ofn.lpstrFile         = szFile; 
	ofn.nMaxFile          = sizeof(szFile); 
	ofn.lpstrFileTitle    = NULL; 
	ofn.nMaxFileTitle     = 0; 
	ofn.lpstrInitialDir   = "C:\\"; 
	ofn.lpstrTitle        = (type ? FIND_WAV : FIND_EXE); 
	ofn.nFileOffset       = 0; 
	ofn.nFileExtension    = 0; 
	ofn.lpstrDefExt       = NULL; 
	ofn.lCustData         = 0; 
	ofn.Flags             = OFN_SHOWHELP | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST 
										 | OFN_HIDEREADONLY; 
	if (GetOpenFileName(&ofn)) {
		if (type)	// Wav file 
			pParent->GetDlgItem(IDC_WAVNAME)->SendMessage(WM_SETTEXT, 0, (LPARAM)ofn.lpstrFile);
		  else		// Application executable
			pParent->GetDlgItem(IDC_EXENAME)->SendMessage(WM_SETTEXT, 0, (LPARAM)ofn.lpstrFile);
		pParent->GetDlgItem(IDOK)->SetFocus();
	}
} 


// Returns app structure associated with a given menu ID

app_struct * find_appId(WPARAM menuId)
{
	app_list * temp;

	temp = applist;
	while (temp->appId != (int)menuId) {
		temp = temp->next;
		if (temp == NULL)
			return NULL;
	}
	return temp->app;
}

BOOL switch_places_a(app_struct *app, int dir)
{
	if (!app)
		return FALSE;
	if (!(app->prevapp) && (dir == UP))
		return FALSE;
	if (!(app->nextapp) && (dir == DOWN))
		return FALSE;
	if (dir == UP) {			// Let's make a mess...
		if (app->nextapp)
			app->nextapp->prevapp = app->prevapp;
		if (app->prevapp->prevapp)
			app->prevapp->prevapp->nextapp = app;
		app->prevapp->nextapp = app->nextapp;
		app->nextapp = app->prevapp;
		app->prevapp = app->prevapp->prevapp;
		app->nextapp->prevapp = app;
		return TRUE;
	  } else {
		if (app->prevapp)
			app->prevapp->nextapp = app->nextapp;
		if (app->nextapp->nextapp)
			app->nextapp->nextapp->prevapp = app;
		app->nextapp->prevapp = app->prevapp;
		app->prevapp = app->nextapp;
		app->nextapp = app->nextapp->nextapp;
		app->prevapp->nextapp = app;
		return TRUE;
	}
}

BOOL switch_places_m(menu_struct *menu, int dir)
{
	if (!menu)
		return FALSE;
	if (!(menu->prevmenu) && (dir == UP))
		return FALSE;
	if (!(menu->nextmenu) && (dir == DOWN))
		return FALSE;
	if (dir == UP) {			// Let's make a mess...
		if (menu->nextmenu)
			menu->nextmenu->prevmenu = menu->prevmenu;
		if (menu->prevmenu->prevmenu)
			menu->prevmenu->prevmenu->nextmenu = menu;
		  else
			glob_menu = menu;
		menu->prevmenu->nextmenu = menu->nextmenu;
		menu->nextmenu = menu->prevmenu;
		menu->prevmenu = menu->prevmenu->prevmenu;
		menu->nextmenu->prevmenu = menu;
		return TRUE;
	  } else {
		if (menu->prevmenu)
			menu->prevmenu->nextmenu = menu->nextmenu;
		  else
			glob_menu = menu->nextmenu;
		if (menu->nextmenu->nextmenu)
			menu->nextmenu->nextmenu->prevmenu = menu;
		menu->nextmenu->prevmenu = menu->prevmenu;
		menu->prevmenu = menu->nextmenu;
		menu->nextmenu = menu->nextmenu->nextmenu;
		menu->prevmenu->nextmenu = menu;
		return TRUE;
	}
}

// Deletes menu list and frees resources

void kill_applist(void)
{
	app_list *curapplist;

	if (applist) {                  // Kill off old app list
		curapplist = applist;
		while (curapplist!=NULL) {
			curapplist = applist->next;
			delete applist;
			applist = curapplist;
		}
	}
}

// Release application linked list memory

void release_app_memory(void)
{             
	menu_struct *menu, *front;
	
	kill_applist();
	menu = glob_menu;
	if (!menu)
		return;
	front = menu->nextmenu;
	while (front!=NULL) {            
		killmenu(menu);
		menu = front;
		front = front->nextmenu;
	}
	killmenu(menu);
}

void ab_message(char * msg, HWND parent)
{
	::MessageBox(parent, msg, "AppBar", MB_OK | MB_ICONEXCLAMATION);
}
