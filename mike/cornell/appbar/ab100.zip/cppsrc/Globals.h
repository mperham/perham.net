// Global variables
#ifndef GLOBALS_H
#define GLOBALS_H

extern menu_struct *glob_menu;
extern app_list *applist;
extern sys_vars sv;
extern user_vars uv;
extern APPBARDATA abd;
extern AppBar ab;

#endif // globals_h
