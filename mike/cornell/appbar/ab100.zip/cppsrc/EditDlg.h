#ifndef EDITDLG_H
#define EDITDLG_H

// EditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// EditDlg dialog

class EditDlg : public CDialog
{
// Construction
public:
	EditDlg(CWnd* pParent = NULL);   // standard constructor

	char menu_sel[30], app_sel[30];
	menu_struct *menus, *newmenu;
	app_struct *apps, *newapp;
	int index;
	hack *phack;   
	AppBarWin *parent;
	CBitmapButton menuup, menudown, appup, appdown;

// Dialog Data
	//{{AFX_DATA(EditDlg)
	enum { IDD = IDD_EDIT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EditDlg)
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(EditDlg)
	afx_msg void OnAppDown();
	afx_msg void OnAppUp();
	afx_msg void OnMenuDown();
	afx_msg void OnMenuUp();
	afx_msg void OnDelApp();
	afx_msg void OnDelMenu();
	afx_msg void OnNewApp();
	afx_msg void OnNewMenu();
	afx_msg void OnSeparator();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	virtual void OnDropFiles(HDROP hd);
	afx_msg void OnDblclkApplist();
	afx_msg void OnDblclkMenulist();
	afx_msg void OnSelchangeMenulist();
	afx_msg void OnSelchangeApplist();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif
