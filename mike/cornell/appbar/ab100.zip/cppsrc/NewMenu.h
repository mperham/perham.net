// NewMenu.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// NewMenu dialog

class NewMenu : public CDialog
{
// Construction
public:
	NewMenu(CWnd* pParent = NULL, hack *ph = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(NewMenu)
	enum { IDD = IDD_NEWMENU };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(NewMenu)
	//}}AFX_VIRTUAL

// Implementation
protected:
	int		index;
	hack	*phack;
	menu_struct *menu, *newmenu;
	app_struct *newapp;
	BOOL	isnew;
	CWnd	*parent;
	void inline ab_message(char *msg);

	// Generated message map functions
	//{{AFX_MSG(NewMenu)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
