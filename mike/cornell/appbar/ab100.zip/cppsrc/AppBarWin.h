// *********************************************************
// AppBar -- Advanced Menu bar for Windows 95/NT
// All code Copyright (C) 1995, 1996 by Mike Perham
// mperham@cs.cornell.edu
// 
// This code MAY NOT be used for any other program without
// my permission and is forbidden in any shareware/commercial
// program.  This code is provided for educational use only
// and there are no guarantees or promises implied.  Blah blah
// *********************************************************

#ifndef APPBARWIN_H
#define APPBARWIN_H
///////////////////////////////////////////////////
// AppBarWin

class AppBarWin : public CWnd 
{
public:
	BOOL IsShown;
	UINT timer;

	AppBarWin();
	~AppBarWin();
	void ab_message(char *msg);
	void HideAppBar(BOOL hide);
	void UpdateMenu(void);
	void ModifyTime(void);
	void Slide(int newy);
	void SyncTime(void);
	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName,
				  DWORD dwStyle, int x, int y, int width, int height,
				  HWND ParentWnd, HMENU nID, LPVOID pContext);
protected:
	// Generated message map functions
	//{{AFX_MSG(EditDlg)
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnNcMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnNcRButtonDown(UINT nHitTest, CPoint point);
//	afx_msg void OnNcLButtonDblClk(UINT nHitTest, CPoint point);
	afx_msg void OnNcPaint();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnTimeChange();
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT id);
	afx_msg void OnSetFocus(CWnd *wnd);
	afx_msg void OnWindowPosChanged(WINDOWPOS* lpwndpos);
	afx_msg LONG OnPowerBroadcast(UINT event, LONG data);
	afx_msg LONG OnDisplayChange(UINT wParam, LONG lParam);
	afx_msg LONG OnHotKey(UINT, LONG);
	afx_msg void OnEdit();
	afx_msg void OnAbout();
	afx_msg void OnOptions();
	afx_msg void OnExit();
	afx_msg void OnAppSelect(UINT id);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif
