// *********************************************************
// AppBar -- Advanced Menu bar for Windows 95/NT
// All code Copyright (C) 1995, 1996 by Mike Perham
// mperham@cs.cornell.edu
// 
// This code MAY NOT be used for any other program without
// my permission and is forbidden in any shareware/commercial
// program.  This code is provided for educational use only
// and there are no guarantees or promises implied.  Blah blah
// *********************************************************

#define STRICT

#include <afxwin.h>
#include <afxext.h>				// CBitmapButton
#include <commdlg.h>			// GetOpenFileName()
#include <mmsystem.h>           // PlaySound()
#include <shellapi.h>           // ShellExecute() and SHAppBarMessage()
#include <stdio.h>              // sprintf, fopen, fclose, fread, fwrite
#include <io.h>                 // _filelength
#include <direct.h>
#include "resource.h"
#include "Strings.h"
#include "AppBarWin.h"
#include "AppBarMain.h"
#include "AboutDlg.h"
#include "EditDlg.h"
#include "NewMenu.h"
#include "NewApp.h"
#include "OptDlg.h"

#ifndef _WINNT
	#include <shlobj.h>			// IShellLink
#endif

