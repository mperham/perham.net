// *********************************************************
// AppBar -- Advanced Menu bar for Windows 95/NT
// All code Copyright (C) 1995, 1996 by Mike Perham
// mperham@cs.cornell.edu
// 
// This code MAY NOT be used for any other program without
// my permission and is forbidden in any shareware/commercial
// program.  This code is provided for educational use only
// and there are no guarantees or promises implied.  Blah blah
// *********************************************************

// NewApp.cpp : implementation file
//

#include "appbar.h"
#include "globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// NewApp dialog


NewApp::NewApp(CWnd* pParent /*=NULL*/, hack *ph)
	: CDialog(NewApp::IDD, pParent)
{
	//{{AFX_DATA_INIT(NewApp)
	//}}AFX_DATA_INIT
	phack = ph;
	parent = pParent;
	isnew = NULL;
}

void inline NewApp::ab_message(char *msg)
{
	MessageBox(msg, "AppBar", MB_OK | MB_ICONINFORMATION);
}

BEGIN_MESSAGE_MAP(NewApp, CDialog)
	//{{AFX_MSG_MAP(NewApp)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// NewApp message handlers

void NewApp::OnOK() 
{
	char buf1[80], buf2[30];

	GetDlgItem(IDC_EXENAME)->SendMessage(WM_GETTEXT, sizeof(buf1), (LPARAM)buf1);
	GetDlgItem(IDC_APPNAME)->SendMessage(WM_GETTEXT, sizeof(buf2), (LPARAM)buf2);
	if ((!strcmp(buf1, "")) || (!strcmp(buf2, ""))) {
		ab_message(ERROR_NAME_FILENAME);
        return;
    }
	GetDlgItem(IDC_EXENAME)->SendMessage(WM_GETTEXT, sizeof(pnewapp->appexe), (LPARAM)pnewapp->appexe);
	GetDlgItem(IDC_APPNAME)->SendMessage(WM_GETTEXT, sizeof(pnewapp->appname), (LPARAM)pnewapp->appname);
    GetDlgItem(IDC_PARAMETERS)->SendMessage(WM_GETTEXT, sizeof(pnewapp->params), (LPARAM)pnewapp->params);
    GetDlgItem(IDC_WORKINGDIR)->SendMessage(WM_GETTEXT, sizeof(pnewapp->workingdir), (LPARAM)pnewapp->workingdir);
	if (!strcmp(pnewapp->workingdir, "")) {
		char drive[40], path[80];
		_splitpath(pnewapp->appexe, drive, path, NULL, NULL);
		sprintf(pnewapp->workingdir, "%s%s", drive, path);
		int len = strlen(pnewapp->workingdir);
		if (len>3)
			// remove trailing backslash on directory
			*(pnewapp->workingdir + len - 1) = '\0';
	}
	if (IsDlgButtonChecked(IDC_NORMAL))
		pnewapp->show = SW_RESTORE;
	  else if (IsDlgButtonChecked(IDC_MAX))
		pnewapp->show = SW_MAXIMIZE;
	  else if (IsDlgButtonChecked(IDC_MIN))
		pnewapp->show = SW_MINIMIZE;
	if (isnew) {
		if (phack->app) {
			phack->app->nextapp = pnewapp;
			pnewapp->prevapp = phack->app;
		  } else {			// first app in menu
		  	phack->menu->nextapp = pnewapp;
			pnewapp->prevapp = NULL;
		}
		menu->numapps++;
		parent->SendDlgItemMessage(IDC_APPLIST, LB_INSERTSTRING, (WPARAM) -1, (LPARAM)pnewapp->appname);
	  } else {
		parent->SendDlgItemMessage(IDC_APPLIST, LB_DELETESTRING, index, 0);
   		parent->SendDlgItemMessage(IDC_APPLIST, LB_INSERTSTRING, index, (LPARAM)pnewapp->appname);
	}
	EndDialog(TRUE);
}

void NewApp::OnCancel() 
{
	if (isnew)
   		delete pnewapp;
	CDialog::OnCancel();
}

BOOL NewApp::OnInitDialog()
{
	CDialog::OnInitDialog();

	isnew = phack->isnew;
	if (isnew) {
		menu = phack->menu;
		pnewapp = new app_struct;
	  } else 
		pnewapp = phack->app;
	switch (pnewapp->show) {
		case SW_MAXIMIZE:
			check_button = IDC_MAX;
			break;
		case SW_MINIMIZE:
			check_button = IDC_MIN;
			break;
		default:
			check_button = IDC_NORMAL;
			break;
	}
	CheckRadioButton(IDC_NORMAL, IDC_MIN, check_button);
	index = parent->SendDlgItemMessage(IDC_APPLIST, LB_GETCURSEL, 0, 0);
	GetDlgItem(IDC_EXENAME)->SendMessage(WM_SETTEXT, 0, (LPARAM)pnewapp->appexe);
	GetDlgItem(IDC_APPNAME)->SendMessage(WM_SETTEXT, 0, (LPARAM)pnewapp->appname);
	GetDlgItem(IDC_WORKINGDIR)->SendMessage(WM_SETTEXT, 0, (LPARAM)pnewapp->workingdir);
	GetDlgItem(IDC_PARAMETERS)->SendMessage(WM_SETTEXT, 0, (LPARAM)pnewapp->params);
	GetDlgItem(IDC_APPNAME)->SetFocus();
	return FALSE;
}

void NewApp::OnBrowse() 
{
	DoBrowse(0, this);
}
