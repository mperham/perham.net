// *********************************************************
// AppBar -- Advanced Menu bar for Windows 95/NT
// All code Copyright (C) 1995, 1996 by Mike Perham
// mperham@cs.cornell.edu
// 
// This code MAY NOT be used for any other program without
// my permission and is forbidden in any shareware/commercial
// program.  This code is provided for educational use only
// and there are no guarantees or promises implied.  Blah blah
// *********************************************************

// NewMenu.cpp : implementation file
//

#include "appbar.h"
#include "globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// NewMenu dialog


NewMenu::NewMenu(CWnd* pParent /*=NULL*/, hack *ph)
	: CDialog(NewMenu::IDD, pParent)
{
	//{{AFX_DATA_INIT(NewMenu)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	phack = ph;
	isnew = NULL;
	parent = pParent;
}

void inline NewMenu::ab_message(char *msg)
{
	MessageBox(msg, "AppBar", MB_OK | MB_ICONINFORMATION);
}

BEGIN_MESSAGE_MAP(NewMenu, CDialog)
	//{{AFX_MSG_MAP(NewMenu)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// NewMenu message handlers

void NewMenu::OnOK() 
{
	char buffer[30];

	GetDlgItem(IDC_MENUNAME)->SendMessage(WM_GETTEXT, sizeof(buffer), (LPARAM)buffer);
	if (!strcmp(buffer,"")) {
		ab_message(ERROR_MENUNAME);
		return;
	}
	strcpy(newmenu->menuname, buffer);
	if (!isnew) {
		parent->SendDlgItemMessage(IDC_MENULIST, LB_DELETESTRING, index, 0);
		parent->SendDlgItemMessage(IDC_MENULIST, LB_INSERTSTRING, index, (LPARAM) (LPCSTR)newmenu->menuname);
	  } else
		parent->SendDlgItemMessage(IDC_MENULIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM) (LPCSTR)newmenu->menuname);
	CDialog::OnOK();
}

BOOL NewMenu::OnInitDialog() 
{
	CDialog::OnInitDialog();

	newmenu = phack->menu;
	isnew = phack->isnew;
	if (isnew)
		if (newmenu) {
			newmenu->nextmenu = new menu_struct;
			newmenu->nextmenu->prevmenu = newmenu;
			newmenu = newmenu->nextmenu;
		  } else {
			glob_menu = new menu_struct;
			newmenu = glob_menu;
		}
	GetDlgItem(IDC_MENUNAME)->SetFocus();
	GetDlgItem(IDC_MENUNAME)->SendMessage(WM_SETTEXT, 0, (LPARAM)newmenu->menuname);
	index = parent->SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	return FALSE;
}

void NewMenu::OnCancel() 
{
	if (isnew) {
		delete newmenu;
		phack->menu->nextmenu = NULL;
	}
	CDialog::OnCancel();
}
