// *********************************************************
// AppBar -- Advanced Menu bar for Windows 95/NT
// All code Copyright (C) 1995, 1996 by Mike Perham
// mperham@cs.cornell.edu
// 
// This code MAY NOT be used for any other program without
// my permission and is forbidden in any shareware/commercial
// program.  This code is provided for educational use only
// and there are no guarantees or promises implied.  Blah blah
// *********************************************************

// EditDlg.cpp : implementation file
//

#include "appbar.h"
#include "globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int mymax(int a, int b)
{
	if (a<b)
		return b;
	return a;
}

int mymin(int a, int b)
{
	if (a<b)
		return a;
	return b;
}

/////////////////////////////////////////////////////////////////////////////
// EditDlg dialog

EditDlg::EditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(EditDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(EditDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	parent = (AppBarWin *) pParent;
}

BEGIN_MESSAGE_MAP(EditDlg, CDialog)
	//{{AFX_MSG_MAP(EditDlg)
	ON_BN_CLICKED(IDC_APPDOWN, OnAppDown)
	ON_BN_CLICKED(IDC_APPUP, OnAppUp)
	ON_BN_CLICKED(IDC_MENUDOWN, OnMenuDown)
	ON_BN_CLICKED(IDC_MENUUP, OnMenuUp)
	ON_BN_CLICKED(IDB_DELAPP, OnDelApp)
	ON_BN_CLICKED(IDB_DELMENU, OnDelMenu)
	ON_BN_CLICKED(IDB_NEWAPP, OnNewApp)
	ON_BN_CLICKED(IDB_NEWMENU, OnNewMenu)
	ON_BN_CLICKED(IDB_SEPARATOR, OnSeparator)
	ON_WM_DROPFILES()
	ON_LBN_DBLCLK(IDC_APPLIST, OnDblclkApplist)
	ON_LBN_DBLCLK(IDC_MENULIST, OnDblclkMenulist)
	ON_LBN_SELCHANGE(IDC_MENULIST, OnSelchangeMenulist)
	ON_LBN_SELCHANGE(IDC_APPLIST, OnSelchangeApplist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// EditDlg message handlers

void EditDlg::OnAppDown()
{
	menus = glob_menu;
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT,(WPARAM) index,(LPARAM)((LPSTR) menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	apps = menus->nextapp;
	index = SendDlgItemMessage(IDC_APPLIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_ITEM, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_APPLIST, LB_GETTEXT,(WPARAM) index,(LPARAM)((LPSTR) app_sel));
	apps = find_app(apps, app_sel);
	ASSERT(apps);
	if (apps->prevapp)
		if (apps->prevapp->separator)
			index--;
	if (menus->nextapp == apps)
		menus->nextapp = menus->nextapp->nextapp;
	switch_places_a(apps, DOWN);
	SendDlgItemMessage(IDC_APPLIST, LB_RESETCONTENT, 0, 0);
	for (apps = menus->nextapp; apps; apps = apps->nextapp) {
		if (apps->separator) 
			SendDlgItemMessage(IDC_APPLIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM)((LPSTR)SEPARATOR_STRING));
		SendDlgItemMessage(IDC_APPLIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM)((LPSTR)apps->appname));
	}
	GetDlgItem(IDC_APPLIST)->SetFocus();
	int num = SendDlgItemMessage(IDC_APPLIST, LB_GETCOUNT, 0, 0);
	SendDlgItemMessage(IDC_APPLIST, LB_SETCURSEL, (WPARAM) mymin(++index, --num), 0);
}

void EditDlg::OnAppUp()
{
	menus = glob_menu;
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT,(WPARAM) index,(LPARAM)((LPSTR) menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	apps = menus->nextapp;
	index = SendDlgItemMessage(IDC_APPLIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_ITEM, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_APPLIST, LB_GETTEXT,(WPARAM) index,(LPARAM)((LPSTR) app_sel));
	apps = find_app(apps, app_sel);
	ASSERT(apps);
	if (apps->nextapp)
		if (apps->nextapp->separator)
			index++;
	if (menus->nextapp->nextapp)
		if (menus->nextapp->nextapp == apps)
			menus->nextapp = menus->nextapp->nextapp;
	switch_places_a(apps, UP);
	SendDlgItemMessage(IDC_APPLIST, LB_RESETCONTENT, 0, 0);
	for (apps = menus->nextapp; apps; apps = apps->nextapp) {
		if (apps->separator) 
			SendDlgItemMessage(IDC_APPLIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM)((LPSTR)SEPARATOR_STRING));
		SendDlgItemMessage(IDC_APPLIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM)((LPSTR)apps->appname));
	}
	GetDlgItem(IDC_APPLIST)->SetFocus();
	SendDlgItemMessage(IDC_APPLIST, LB_SETCURSEL, (WPARAM) mymax(0, --index), 0);
}

void EditDlg::OnDelApp() 
{
	BOOL flag = FALSE;

	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	index = SendDlgItemMessage(IDC_APPLIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_ITEM, ab.abwin->GetSafeHwnd());return;}
	BOOL sep = FALSE;  // whether we should delete the separator
	SendDlgItemMessage(IDC_APPLIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)app_sel));
	if (!strcmp(app_sel,SEPARATOR_STRING))  {       // User wants to delete a separator
		SendDlgItemMessage(IDC_APPLIST, LB_GETTEXT, (WPARAM)++index, (LPARAM)((LPSTR)app_sel));
		index--;
		sep = TRUE;
	}
	apps = menus->nextapp;
	apps = find_app(apps, app_sel);
	ASSERT(apps);
	if (sep)        // If we are deleting sep, just reset variable
		apps->separator = FALSE;
	  else {    // else kill app structure
		if (apps->separator) {
			SendDlgItemMessage(IDC_APPLIST, LB_DELETESTRING, --index, 0);
			flag = TRUE;
		}
		if (menus->nextapp == apps)
			menus->nextapp = apps->nextapp;
		killapp(apps);
		menus->numapps--;
	}
	SendDlgItemMessage(IDC_APPLIST, LB_DELETESTRING, (WPARAM)index, 0);
	GetDlgItem(IDC_APPLIST)->SetFocus();
	if (flag) index--;
	SendDlgItemMessage(IDC_APPLIST, LB_SETCURSEL, (WPARAM)index, 0);
}

void EditDlg::OnDelMenu() 
{
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	int i = MessageBox(CONFIRM_DELETE, CONFIRM_DELETE_TITLE, MB_YESNO);
	if (i == IDYES) {
		killmenu(menus);
		SendDlgItemMessage(IDC_MENULIST, LB_DELETESTRING, (WPARAM)index, 0);
		SendDlgItemMessage(IDC_APPLIST, LB_RESETCONTENT, 0, 0);
	}
	GetDlgItem(IDC_MENULIST)->SetFocus();
	SendDlgItemMessage(IDC_MENULIST, LB_SETCURSEL, (WPARAM) index, 0);
}

void EditDlg::OnMenuDown()
{
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	switch_places_m(menus, DOWN);
	SendDlgItemMessage(IDC_MENULIST, LB_RESETCONTENT, 0, 0);
	for (menus = glob_menu; menus; menus = menus->nextmenu)
		SendDlgItemMessage(IDC_MENULIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM)((LPSTR)menus->menuname));
	GetDlgItem(IDC_MENULIST)->SetFocus();
	int num = SendDlgItemMessage(IDC_MENULIST, LB_GETCOUNT, 0, 0);
	SendDlgItemMessage(IDC_MENULIST, LB_SETCURSEL, (WPARAM) mymin(++index, --num), 0);
}

void EditDlg::OnMenuUp()
{
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	switch_places_m(menus, UP);
	SendDlgItemMessage(IDC_MENULIST, LB_RESETCONTENT, 0, 0);
	for (menus = glob_menu; menus; menus = menus->nextmenu)
		SendDlgItemMessage(IDC_MENULIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM)((LPSTR)menus->menuname));
	GetDlgItem(IDC_MENULIST)->SetFocus();
	SendDlgItemMessage(IDC_MENULIST, LB_SETCURSEL, (WPARAM) mymax(0, --index), 0);
}

void EditDlg::OnNewApp() 
{
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	newapp = menus->nextapp;
	if (newapp) 
		while (newapp->nextapp)
			newapp = newapp->nextapp;
	hack Hack;
	Hack.isnew = TRUE;
	Hack.app = newapp;
	Hack.menu = menus;

	NewApp na(this, &Hack);
	na.DoModal();
}

void EditDlg::OnNewMenu() 
{
	newmenu = glob_menu;
	ASSERT(newmenu);
	while (newmenu->nextmenu)
		newmenu = newmenu->nextmenu;
	hack Hack;
	Hack.isnew = TRUE;
	Hack.app = NULL;
	Hack.menu = newmenu;

	NewMenu nm(this, &Hack);
	nm.DoModal();
}

void EditDlg::OnSeparator() 
{
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)menu_sel));
	menus = find_menu(menu_sel);
	ASSERT(menus);
	index = SendDlgItemMessage(IDC_APPLIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_ITEM, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_APPLIST, LB_GETTEXT, (WPARAM)index, (LPARAM)((LPSTR)app_sel));
	apps = menus->nextapp;
	apps = find_app(apps, app_sel);
	ASSERT(apps);
	if (apps->separator) return;  // Can't add a second separator!
	apps->separator = TRUE;
	SendDlgItemMessage(IDC_APPLIST, LB_INSERTSTRING, (WPARAM)index, (LPARAM)((LPSTR)SEPARATOR_STRING));
}

void EditDlg::OnOK() 
{
	ab.SaveMenu();
	parent->UpdateMenu();
	parent->ModifyTime();
	CDialog::OnOK();
}

BOOL EditDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	menuup.AutoLoad(IDC_MENUUP, this);
	menudown.AutoLoad(IDC_MENUDOWN, this);
	appup.AutoLoad(IDC_APPUP, this);
	appdown.AutoLoad(IDC_APPDOWN, this);

	for (menus = glob_menu; menus; menus = menus->nextmenu)
		SendDlgItemMessage(IDC_MENULIST, LB_INSERTSTRING, (WPARAM)-1, (LPARAM)((LPSTR)menus->menuname));
	menus = glob_menu;
	GetDlgItem(IDC_MENULIST)->DragAcceptFiles(TRUE);
	GetDlgItem(IDB_DELMENU)->EnableWindow(FALSE);
	GetDlgItem(IDB_DELAPP)->EnableWindow(FALSE);
	GetDlgItem(IDB_SEPARATOR)->EnableWindow(FALSE);
	return TRUE;
}

void EditDlg::OnDropFiles(HDROP hd)
{
	RECT r;
	POINT p;
	div_t dt;
	int i, num, width;
	char *last_slash, *last_period, *name;

	num = DragQueryFile(hd, 0xFFFFFFFF, 0, 0);
	DragQueryPoint(hd, &p);
	SendDlgItemMessage(IDC_MENULIST, LB_GETITEMRECT, 0, (LPARAM)&r);
	width = r.bottom - r.top;
	dt = div(p.y, width);
	dt.quot += SendDlgItemMessage(IDC_MENULIST, LB_GETTOPINDEX, 0, 0);
	menus = glob_menu;
	if (!menus) {DragFinish(hd); return;}
	for (i=0;i<dt.quot;i++) {
		if (menus->nextmenu)
			menus = menus->nextmenu;
		  else {DragFinish(hd); return;}
	}
	while (num--)   {
		apps = menus->nextapp;
		if (apps)
			while (apps->nextapp)
				apps = apps->nextapp;
		if (apps) {
			apps->nextapp = new app_struct;
			apps->nextapp->prevapp = apps;
			apps = apps->nextapp;
		  }     else {
			menus->nextapp = new app_struct;
			menus->nextapp->prevapp = NULL;
			apps = menus->nextapp;
		}
		DragQueryFile(hd, num, apps->appexe, sizeof(apps->appexe));
		last_slash = strrchr(apps->appexe, 0x5C);  // backslash
		last_period = strrchr(apps->appexe, 0x2E); // period
		if (!last_slash) 
			last_slash = (char *) apps->appexe;
		if (!last_period)
			strcpy(apps->appname, last_slash);
		  else { 
			last_slash++;
			name = (char *) apps->appname;
			while (last_slash != last_period) {
				*last_slash = tolower(*last_slash);
				*name++ = *last_slash++;
			}
		}
		apps->appname[0] = (char) toupper((int)apps->appname[0]);
		if (!strcmp(apps->appname, ""))
			strcpy(apps->appname, DEFAULT_NAME);
		menus->numapps++;

		char drive[40], path[80];
		_splitpath(apps->appexe, drive, path, NULL, NULL);
		sprintf(apps->workingdir, "%s%s", drive, path);
		int len = strlen(apps->workingdir);
		// we don't want to remove the \ in c:\
		if (len>3)
			// remove trailing backslash on directory
			*(apps->workingdir + len - 1) = '\0';
		SendDlgItemMessage(IDC_MENULIST, LB_SETCURSEL, i, 0);
		GetDlgItem(IDC_MENULIST)->SetFocus();
	}
	DragFinish(hd);
	return;
}

void EditDlg::OnDblclkApplist() 
{
	menus = glob_menu;
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT,(WPARAM)  index,(LPARAM)((LPSTR) menu_sel));
	menus = find_menu(menu_sel);
	if (!menus) return;
	apps = menus->nextapp;
	index = SendDlgItemMessage(IDC_APPLIST, LB_GETCURSEL, 0, 0);
	SendDlgItemMessage(IDC_APPLIST, LB_GETTEXT,(WPARAM) index,(LPARAM)((LPSTR) app_sel));
	apps = find_app(apps, app_sel);
	if (!apps) return;
	hack Hack;
	Hack.app = apps;
	Hack.isnew = FALSE;
	Hack.menu = menus;

	NewApp na(this, &Hack);
	na.DoModal();
	SendDlgItemMessage(IDC_APPLIST, LB_SETCURSEL, index, 0);
}

void EditDlg::OnDblclkMenulist() 
{
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	if (index == LB_ERR) {ab_message(SELECT_MENU, ab.abwin->GetSafeHwnd());return;}
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT,(WPARAM) index,(LPARAM)((LPSTR) menu_sel));
	menus = find_menu(menu_sel);
	if (!menus) return;
	hack Hack;
	Hack.isnew = FALSE;
	Hack.app = NULL;
	Hack.menu = menus;
	
	NewMenu nm(this, &Hack);
	nm.DoModal();
	SendDlgItemMessage(IDC_MENULIST, LB_SETCURSEL, index, 0);
}

void EditDlg::OnSelchangeMenulist() 
{
	GetDlgItem(IDB_DELMENU)->EnableWindow(TRUE);
	index = SendDlgItemMessage(IDC_MENULIST, LB_GETCURSEL, 0, 0);
	SendDlgItemMessage(IDC_MENULIST, LB_GETTEXT,(WPARAM) index,(LPARAM)((LPSTR) menu_sel));
	menus = find_menu(menu_sel);
	if (!menus) return;
	// Found correct menu, now fill other listbox with apps
	SendDlgItemMessage(IDC_APPLIST, LB_RESETCONTENT, 0,0);
	for (apps = menus->nextapp; apps; apps = apps->nextapp) {
		if (apps->separator)
			SendDlgItemMessage(IDC_APPLIST, LB_ADDSTRING, 0, (LPARAM)((LPSTR) SEPARATOR_STRING));
			SendDlgItemMessage(IDC_APPLIST, LB_ADDSTRING, 0, (LPARAM)((LPSTR) apps->appname));
	}
}

void EditDlg::OnSelchangeApplist() 
{
	GetDlgItem(IDB_DELAPP)->EnableWindow(TRUE);
	GetDlgItem(IDB_SEPARATOR)->EnableWindow(TRUE);
}
