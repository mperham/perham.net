// *********************************************************
// AppBar -- Advanced Menu bar for Windows 95/NT
// All code Copyright (C) 1995, 1996 by Mike Perham
// mperham@cs.cornell.edu
// 
// This code MAY NOT be used for any other program without
// my permission and is forbidden in any shareware/commercial
// program.  This code is provided for educational use only
// and there are no guarantees or promises implied.  Blah blah
// *********************************************************

#ifndef APPBARMAIN_H
#define APPBARMAIN_H

#define AB_HEIGHT				(GetSystemMetrics(SM_CYMENU)+5)
#define AB_WIDTH				(sv.width)
#define PATH_SIZE				128
// Colors for battery percentage
#define RED						RGB(192,0,0)
#define BRIGHT_RED				RGB(255,0,0)
#define GREEN					RGB(0,128,0)
#define YELLOW					RGB(255,255,0)
// Version number for datafile format
#define APPBAR_FILE_VERSION		103
#define TRUE					1
#define FALSE					0
#define SYNC_TIMER				0xF000
#define TIME_UPDATE				0xE000
#define HIDE_TIMER				0xD000
#define SEPARATOR_STRING		"-------"
#define UP						VK_UP       // These 2 are needed for
#define DOWN					VK_DOWN     // switch_places()

#ifdef _WINNT       // overrides for old-style NT v3.x windows
	#undef AB_HEIGHT
	#define AB_HEIGHT			(GetSystemMetrics(SM_CYMENU)+10)
#endif

//////////////////// Structures and classes ////////////////////////////

struct user_vars {
	BOOL stayontop;                 // Does ab always float on top?
	BOOL chime;                     // Play sound every hour?
	BOOL date;                      // Display date on menu bar?
	BOOL memory;                    // Display free memory?
	BOOL bottom;                    // Place AppBar at bottom of screen?
	BOOL autohide;                  // Auto hide AppBar?
	BOOL time;						// Show time?
	BOOL user;						// Show user?
	char wavfile[PATH_SIZE];        // Path/filename of WAV file to play
};

struct sys_vars {
	BOOL newshell;				// This determines whether or not we have the new shell (Start Menu)
	BOOL power;					// This determines if we have power saving (NT doesn't)
								// NT4: newshell == TRUE and power == FALSE
								// Win95: both are TRUE
								// NT3: both are FALSE
	int width;                  // Screen width  (i.e. 800)
	int height;                 // Screen height (ie 600)
	BOOL battery;               // are we on AC or battery?
	char user[30];              // Optional username
	char appfile[PATH_SIZE];    // DAT filename
};

class app_struct {
  public:
	char appexe[PATH_SIZE],     // Path and name of executable
		 workingdir[PATH_SIZE], // Working dir
		 params[90],            // command line parameters
		 appname[30];           // Name of application for menubar
	DWORD show;                 // Maximize, Minimize, etc.
	BOOL separator;             // Separator before this app?
	app_struct *nextapp;        // Pointer to next app
	app_struct *prevapp;
	
	app_struct();
	~app_struct();
};

class menu_struct {
  public:
	char menuname[30];              // name of menu
	int numapps;                    // number of apps in menu
	menu_struct *nextmenu;          // pointer to next menu
	menu_struct *prevmenu;
	app_struct *nextapp;            // pointer to first app in menu
	
	menu_struct();
	~menu_struct();
};


// Used to find appliction structure based on a user-selected menu item

struct app_list {
	int appId;                      // menuID related to app (100*m +a)
	app_struct *app;                // related app structure
	app_list *next;
};                         

// used to pass new menu or app data to window procedure

struct hack {
	app_struct *app;
	menu_struct *menu;
	BOOL isnew;
};

class AppBar : public CWinApp 
{
	public:
	BOOL IsError;
	CString ABClass;
	AppBarWin *abwin;
	char origdir[PATH_SIZE];

#ifdef _DEBUG
	CMemoryState begin, end, diff;
#endif

	void CleanUp(void);
	void ParseCmdArgs(void);
	void GetRegKeys(user_vars *args);
	void MakeNewRegKey(HKEY root);
	void SaveRegKey(void);
	BOOL ReadInApps(void);
	void SaveMenu(void);
	BOOL ShowAppBar(void);
	BOOL InitApplication(void);
	BOOL InitInstance(void);
	void ExitAppBar(BOOL error_exit);
	BOOL IsLink(char *filename);
	BOOL ExecuteApplication(app_struct *app);
	HRESULT GetLinkInfo(LPSTR lpszLinkName, LPSTR lpszFile,
						LPSTR lpszDir, LPSTR lpszArgs, int show);
};

menu_struct * find_menu(char * menu_sel);
app_struct * find_app(app_struct * apps, char * app_sel);
app_struct * find_appId(WPARAM menuId);
BOOL switch_places_a(app_struct *app, int dir);
BOOL switch_places_m(menu_struct *menu, int dir);
void kill_applist(void);
void release_app_memory(void);
void killapp(app_struct *app);
void killmenu(menu_struct *menu);
void ab_message(char *msg, HWND parent);
void DoBrowse(int type, CDialog* parent);
void error(char *err_msg);

#endif
