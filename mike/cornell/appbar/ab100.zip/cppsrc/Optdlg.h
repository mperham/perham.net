#ifndef OPTDLG_H
#define OPTDLG_H
// OptDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// OptDlg dialog

class OptDlg : public CDialog
{
// Construction
public:
	OptDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(OptDlg)
	enum { IDD = IDD_OPTIONS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(OptDlg)
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(OptDlg)
	afx_msg void OnTestWav();
	afx_msg void OnFind();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnAutohide();
	afx_msg void OnBottom();
	afx_msg void OnChime();
	afx_msg void OnDate();
	afx_msg void OnMemory();
	afx_msg void OnStayontop();
	afx_msg void OnTime();
	afx_msg void OnUser();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif