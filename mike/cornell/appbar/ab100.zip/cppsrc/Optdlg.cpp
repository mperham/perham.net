// *********************************************************
// AppBar -- Advanced Menu bar for Windows 95/NT
// All code Copyright (C) 1995, 1996 by Mike Perham
// mperham@cs.cornell.edu
// 
// This code MAY NOT be used for any other program without
// my permission and is forbidden in any shareware/commercial
// program.  This code is provided for educational use only
// and there are no guarantees or promises implied.  Blah blah
// *********************************************************


// OptDlg.cpp : implementation file
//

#include "appbar.h"
#include "globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// OptDlg dialog

OptDlg::OptDlg(CWnd* pParent /*=NULL*/)
	: CDialog(OptDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(OptDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

BEGIN_MESSAGE_MAP(OptDlg, CDialog)
	//{{AFX_MSG_MAP(OptDlg)
	ON_BN_CLICKED(IDB_TESTWAV, OnTestWav)
	ON_BN_CLICKED(IDB_FINDWAV, OnFind)
	ON_BN_CLICKED(IDC_AUTOHIDE, OnAutohide)
	ON_BN_CLICKED(IDC_BOTTOM, OnBottom)
	ON_BN_CLICKED(IDC_CHIME, OnChime)
	ON_BN_CLICKED(IDC_DATE, OnDate)
	ON_BN_CLICKED(IDC_MEMORY, OnMemory)
	ON_BN_CLICKED(IDC_STAYONTOP, OnStayontop)
	ON_BN_CLICKED(IDC_TIME, OnTime)
	ON_BN_CLICKED(IDC_USER, OnUser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// OptDlg message handlers

BOOL OptDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	GetDlgItem(IDC_WAVNAME)->SendMessage(WM_SETTEXT, 0, (LPARAM)uv.wavfile);
	CheckDlgButton(IDC_CHIME, uv.chime);
	CheckDlgButton(IDC_DATE, uv.date);
	CheckDlgButton(IDC_MEMORY, uv.memory);
	CheckDlgButton(IDC_STAYONTOP, uv.stayontop);
	CheckDlgButton(IDC_BOTTOM, uv.bottom);
	CheckDlgButton(IDC_AUTOHIDE, uv.autohide);
	CheckDlgButton(IDC_TIME, uv.time);
	CheckDlgButton(IDC_USER, uv.user);
	return TRUE;  
}

void OptDlg::OnFind()
{
	DoBrowse(1, this);
}

void OptDlg::OnTestWav() 
{
	char buffer[80];

	GetDlgItem(IDC_WAVNAME)->SendMessage(WM_GETTEXT, sizeof(buffer), (LPARAM)buffer);
	if (!strcmp(buffer, "")) {
		ab_message(ERROR_ENTER_WAVNAME, ab.abwin->GetSafeHwnd());
		return;
	}
	if (!PlaySound(buffer, NULL, SND_ASYNC | SND_FILENAME))
		ab_message(ERROR_PLAYING_WAV, ab.abwin->GetSafeHwnd());
}	

void OptDlg::OnOK() 
{
	char buffer[80];

	GetDlgItem(IDC_WAVNAME)->SendMessage(WM_GETTEXT, sizeof(buffer), (LPARAM)buffer);
	if (!strcmp(buffer, "") && uv.chime) {
		ab_message(ERROR_ENTER_WAVNAME, ab.abwin->GetSafeHwnd());
		return;
	}
	strcpy(uv.wavfile, buffer);
	EndDialog(TRUE);
}


void OptDlg::OnAutohide() 
{
	if (sv.newshell) {
		uv.autohide = !uv.autohide;
		CheckDlgButton(IDC_AUTOHIDE, uv.autohide);
		// set or unset the autohide bar for this edge
		abd.cbSize = sizeof(APPBARDATA);
		abd.hWnd = ab.abwin->m_hWnd;
		abd.uEdge = (uv.bottom ? ABE_BOTTOM : ABE_TOP);
		abd.lParam = (uv.autohide ? TRUE : FALSE);
		if (!SHAppBarMessage(ABM_SETAUTOHIDEBAR, &abd)) {
			uv.autohide = FALSE;
			CheckDlgButton(IDC_AUTOHIDE, uv.autohide);
			ab_message(ERROR_AUTOHIDING, ab.abwin->GetSafeHwnd());
			return;
		}
		// update the position of the autohide bar
		if (uv.autohide) {
			abd.rc.top = abd.rc.left = abd.rc.right = abd.rc.bottom = 0;
			SHAppBarMessage(ABM_SETPOS, &abd);
		  } else {
			abd.rc.top = abd.rc.left = 0;
			abd.rc.right = sv.width;
			abd.rc.bottom = sv.height;
			SHAppBarMessage(ABM_QUERYPOS, &abd);
			abd.rc.top = (uv.bottom ? abd.rc.bottom - AB_HEIGHT : abd.rc.top);
			ab.abwin->MoveWindow(abd.rc.top, 0, AB_WIDTH, AB_HEIGHT, TRUE);
			abd.rc.bottom = abd.rc.top + AB_HEIGHT;
			abd.rc.right = AB_WIDTH;
			SHAppBarMessage(ABM_SETPOS, &abd);
		}
		ab.abwin->HideAppBar(uv.autohide);
	} else {
		ab_message(ERROR_AUTOHIDE_NT, ab.abwin->GetSafeHwnd());
		uv.autohide = TRUE;
		CheckDlgButton(IDC_AUTOHIDE, uv.autohide);
	}
}

void OptDlg::OnBottom() 
{
	uv.bottom = !uv.bottom;
	CheckDlgButton(IDC_BOTTOM, uv.bottom);
	ab.abwin->MoveWindow(0, (uv.bottom ? sv.height - AB_HEIGHT : 0),
						AB_WIDTH, AB_HEIGHT, TRUE);
	ab.abwin->ModifyTime();
	if (sv.newshell) {
		// we are changing our onscreen position so
		// we need to reinitialize our appbar system info
		abd.cbSize = sizeof(APPBARDATA);
		abd.hWnd = ab.abwin->m_hWnd;
		abd.uEdge = (uv.bottom ? ABE_BOTTOM : ABE_TOP);
		if (uv.autohide) {
			SHAppBarMessage(ABM_REMOVE, &abd);
			SHAppBarMessage(ABM_NEW, &abd);
			abd.lParam = TRUE;
			if (!SHAppBarMessage(ABM_SETAUTOHIDEBAR, &abd)) {
				// go back to previous edge...
				uv.bottom = !uv.bottom;
				ab.abwin->SetWindowPos(NULL, 0, (uv.bottom ? sv.height - AB_HEIGHT : 0),
										0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
				abd.uEdge = (uv.bottom ? ABE_BOTTOM : ABE_TOP);
				SHAppBarMessage(ABM_SETAUTOHIDEBAR, &abd);
				CheckDlgButton(IDC_BOTTOM, uv.bottom);
				ab_message(ERROR_AUTOHIDING, ab.abwin->GetSafeHwnd());
				return;
			}
		} else {
			abd.rc.top = abd.rc.left = abd.rc.right = abd.rc.bottom = 0;
			abd.rc.right = sv.width;
			abd.rc.bottom = sv.height;
			SHAppBarMessage(ABM_QUERYPOS, &abd);
			abd.rc.left = 0;
			abd.rc.top = (uv.bottom ? abd.rc.bottom - AB_HEIGHT : abd.rc.top);
			abd.rc.bottom = abd.rc.top + AB_HEIGHT;
			abd.rc.right = AB_WIDTH;
			SHAppBarMessage(ABM_SETPOS, &abd);
		}
	} else
		ab.abwin->HideAppBar(TRUE);
}

void OptDlg::OnChime() 
{
	uv.chime = !uv.chime;
}

void OptDlg::OnDate() 
{
	uv.date = !uv.date;
	ab.abwin->ModifyTime();
}

void OptDlg::OnMemory() 
{
	uv.memory = !uv.memory;
	ab.abwin->ModifyTime();
}

void OptDlg::OnStayontop() 
{
	uv.stayontop = !uv.stayontop;
	ab.abwin->SetWindowPos((uv.stayontop ? &wndTopMost : &wndNoTopMost),
	   				0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

void OptDlg::OnTime() 
{
	uv.time = !uv.time;	
	ab.abwin->ModifyTime();
}

void OptDlg::OnUser() 
{
	uv.user = !uv.user;
	ab.abwin->ModifyTime();
}
