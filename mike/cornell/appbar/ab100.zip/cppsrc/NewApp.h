// NewApp.h : header file
//

#ifndef NEWAPP_H
#define NEWAPP_H

/////////////////////////////////////////////////////////////////////////////
// NewApp dialog

class NewApp : public CDialog {
// Construction
public:
	NewApp(CWnd* pParent = NULL, hack *ph = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(NewApp)
	enum { IDD = IDD_NEWAPP };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(NewApp)
	//}}AFX_VIRTUAL

// Implementation
protected:
	app_struct *pnewapp;
	menu_struct *menu;
	BOOL isnew;
	hack *phack;
	int index;
	int check_button;
	CWnd *parent;
	void inline ab_message(char *msg);

	// Generated message map functions
	//{{AFX_MSG(NewApp)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif