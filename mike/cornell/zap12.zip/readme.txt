Zap! - a software thing to do stuff, amongst other things... v1.2

HowTo ------------------

Zap! has 3 operating modes: random, bitmap and color.  Each mode takes
a value.  In the case of random, the value is the directory from which to
select a BMP.  With bitmap, it is a specific bitmap file and with color it
is a 6-digit HEX color value: BBGGRR.

Zap! stores your latest preferences in the Registry so you can have a
favorite color, specific random directory and a favorite BMP.

Zap! also accepts command-line parameters:

	Zap [-exit] [-min] mode value

	-exit tells Zap! to carry out the specified action and then exit.
	      No window will appear on screen.
 	-min tells Zap! to start up minimized.
 	 
	Modes:
	-bitmap   - Change desktop bitmap to the bitmap file given
	-random   - Randomly select a bitmap from the directory given
	-color    - change desktop color to the RGB value given

	value is the related value with the mode: dir, bitmap file or HEX 
	color value.

Examples:

	Zap -bitmap z:\mjp6\bmps\fire.bmp -exit
	Zap -color 0F0F00 -min
	Zap -random z:\mjp6\bmps

Money ----------------

 It's askware.  I ask that you send me $5 if you like this program.
 I'll throw in a free license for AppBar too.
 
Trivia --------------

 Mike Perham
 630 Stewart Ave
 Ithaca NY 14850 
 mperham@cs.cornell.edu
 http://www.cs.cornell.edu/Info/Peole/mperham

Answers to FAQ ------

A. You can remove the current bitmap by setting the bitmap value to (none)
   and clicking Change.
