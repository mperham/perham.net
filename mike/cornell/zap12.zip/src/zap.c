/* Zap! - Random Bitmap Changer for Win32
 *
 * Alot of this file is copied from the TRAYNOT sample in VC4.x and
 * a guide to using dialog boxes as your main window I found on the
 * Web.
 *
 */

#include "zap.h"


BOOL startup = TRUE;
BOOL tile = FALSE;

void mb(char *msg)
{
	MessageBox(NULL, msg, "Zap!", MB_ICONERROR);
}

/* Counts the number of *.BMPs in \bmp.random_dir and then
 * selects one at random
 */

void randomBMP(void)
{
	char *mask = "*.bmp";
	WIN32_FIND_DATA wfd;
	int numBmps = 0;
	int pick;
	HANDLE handle;
	char file[MAX_PATH];
	char dir[MAX_PATH];

	srand(time(NULL));
	strcpy(file, bmp.random_dir);
	strcpy(dir, bmp.random_dir);
	strcat(file, "\\");
	strcat(dir, "\\");
	strcat(dir, mask);
	handle = FindFirstFile(dir, &wfd);
	if (handle == INVALID_HANDLE_VALUE) {
		sprintf(errMsg, "No BMPs found in %s", dir);
		mb(errMsg);
		return;
	} else
		numBmps++;

	while (FindNextFile(handle, &wfd))
		numBmps++;
	FindClose(handle);

	do {
		pick = rand() % numBmps;
	} while (pick == bmp.prev_pick);

	bmp.prev_pick = pick;

	handle = FindFirstFile(dir, &wfd);
	while (pick) {
		FindNextFile(handle, &wfd);
		pick--;
	}
	FindClose(handle);

	strcat(file, wfd.cFileName);
	if (!SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, file, 0))
		mb("Error changing desktop bitmap!");
}


int WINAPI WinMain(HINSTANCE hInstance,	HINSTANCE hPrevInstance,
					LPSTR lpCmdLine, int nCmdShow)	
{
	BOOL exit = FALSE;
	WNDCLASS dc;
	int rc;

	exit = ParseArgs();

	if (exit || (FindWindow(NULL, "Zap!")))
		return 0;
	
	dc.style = 0;
	dc.lpfnWndProc = DefDlgProc;
	dc.cbClsExtra = 0;
	dc.cbWndExtra = DLGWINDOWEXTRA;
	dc.hInstance = hInstance;
	hIcon = dc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
	dc.hCursor = LoadCursor(NULL, IDC_ARROW);
	dc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	dc.lpszClassName = "ZapDlg";
	RegisterClass(&dc);
  
	rb_inst = hInstance;
	GetOptions();
	rc = DialogBox(rb_inst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)MainDlgProc);
	return 0;
}

/* Changes desktop to a 6-digit RGB value */

void parseColors(void)
{
	unsigned long col;
	int area;

	if (!sscanf(bmp.color, "%x", &col)) {
		mb("Invalid RGB value!  Must be a 6-digit hex value: BBGGRR.");
		return;
	}
	area = COLOR_DESKTOP;
	SetSysColors(1, &area, &col);
}


BOOL CALLBACK MainDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	int i;
	BOOL rc;
	char tileStr[10];
	HKEY root;
	DWORD type, size;

	switch (msg) {
		case WM_INITDIALOG:
			TrayProc(hwnd, NIM_ADD, 0, (HICON) LoadImage(rb_inst, MAKEINTRESOURCE(IDI_ICON1),
					IMAGE_ICON, 16, 16, 0), "Zap!");
			/////////////////////////////////////////////
			mode = bmp.cur_mode;
			switch (mode) {
				case IDC_BMP:
					CheckDlgButton(hwnd, IDC_BMP, BST_CHECKED);
					SendMessage(GetDlgItem(hwnd, IDC_VALUE), WM_SETTEXT, MAX_PATH,
							(LPARAM)bmp.bitmap);
					break;
				case IDC_COLOR:
					CheckDlgButton(hwnd, IDC_COLOR, BST_CHECKED);
					SendMessage(GetDlgItem(hwnd, IDC_VALUE), WM_SETTEXT, 7,
							(LPARAM)bmp.color);
					break;
				case IDC_RANDOM:
					CheckDlgButton(hwnd, IDC_RANDOM, BST_CHECKED);
					SendMessage(GetDlgItem(hwnd, IDC_VALUE), WM_SETTEXT, MAX_PATH,
							(LPARAM)bmp.random_dir);
					break;
			}
			//////////////////////////////////////////////
			RegCreateKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, NULL, 
					REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &root, NULL);
			RegQueryValueEx(root, "TileWallpaper", 0, &type, tileStr, &size);
			RegCloseKey(root);
			if (tileStr[0] == '1') {
				CheckDlgButton(hwnd, ID_TILE, BST_CHECKED);
				tile = TRUE;
			}
			//////////////////////////////////////////////
			if (start_state == SW_HIDE) {
				PostMessage(hwnd, WM_COMMAND, ID_HIDE, 0);
			}
			break;
		case WM_SHOWWINDOW:
			if ((wParam == TRUE) && (startup == TRUE)) {
				if (start_state == SW_HIDE) {
					startup = FALSE;
					rc = PostMessage(hwnd, WM_COMMAND, ID_HIDE, 0);
				}
			}
			break;
		case WM_DRAWITEM:
			return IconDrawItem((LPDRAWITEMSTRUCT)lParam);
		case WM_CLOSE:
			SaveOptions();
			TrayProc(hwnd, NIM_DELETE, 0, NULL, "Zap!");
			DestroyIcon(hIcon);
			EndDialog(hwnd, wParam);
			break;
		case WM_COMMAND:
			return CommandHandler(hwnd, msg, wParam, lParam);
		case WM_TRAYICON:
			switch (lParam) {
				case WM_LBUTTONDOWN:
					ShowWindow(hwnd, SW_SHOW);
					SetForegroundWindow(hwnd);
					break;
				case WM_RBUTTONDOWN:
					pm1 = LoadMenu(rb_inst, MAKEINTRESOURCE(IDR_MENU));
					pm = GetSubMenu(pm1, 0);
					for (i=IDC_BMP;i<=IDC_RANDOM;i++) {
						CheckMenuItem(pm, i, (i == mode ? MF_CHECKED : MF_UNCHECKED));
					}
					if (tile) {
						CheckMenuItem(pm, ID_TILE, MF_CHECKED);
					}
					GetCursorPos(&pt);
					TrackPopupMenuEx(pm, TPM_LEFTALIGN | TPM_LEFTBUTTON, pt.x, pt.y, hwnd, NULL);
					break;
				default:
					break;
			}
		default:
			return FALSE;
    }
    return TRUE;
}

BOOL CommandHandler(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
	char value[MAX_PATH];
	char tileStr[2];
	HKEY root;

	switch (LOWORD(wp)) {
		case IDC_CHANGE:
			SendMessage(GetDlgItem(hwnd, IDC_VALUE), WM_GETTEXT, MAX_PATH, (LPARAM)value);
			switch (mode) {
				case IDC_COLOR:
					if (strlen(value) != 6) {
						mb("Invalid RGB value!  Must be a 6-digit hex value: BBGGRR.");
						return TRUE;
					}
					strcpy(bmp.color, value);
					parseColors();
					break;
				case IDC_BMP:
					strcpy(bmp.bitmap, value);
					SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, bmp.bitmap, 0);
					break;
				case IDC_RANDOM:
					strcpy(bmp.random_dir, value);
					randomBMP();
					break;
			}
			return TRUE;
		case IDC_BMP:
			CheckDlgButton(hwnd, mode, BST_UNCHECKED);
			mode = bmp.cur_mode = IDC_BMP;
			CheckDlgButton(hwnd, mode, BST_CHECKED);
			SendMessage(GetDlgItem(hwnd, IDC_VALUE), WM_SETTEXT, MAX_PATH, (LPARAM)bmp.bitmap);
			break;
		case IDC_RANDOM:
			CheckDlgButton(hwnd, mode, BST_UNCHECKED);
			mode = bmp.cur_mode = IDC_RANDOM;
			CheckDlgButton(hwnd, mode, BST_CHECKED);
			SendMessage(GetDlgItem(hwnd, IDC_VALUE), WM_SETTEXT, MAX_PATH, (LPARAM)bmp.random_dir);
			break;
		case IDC_COLOR:
			CheckDlgButton(hwnd, mode, BST_UNCHECKED);
			mode = bmp.cur_mode = IDC_COLOR;
			CheckDlgButton(hwnd, mode, BST_CHECKED);
			SendMessage(GetDlgItem(hwnd, IDC_VALUE), WM_SETTEXT, 7, (LPARAM)bmp.color);
			break;
		case ID_TILE:
			tile = !tile;
			tileStr[1] = '\0';
			if (tile) {
				CheckDlgButton(hwnd, ID_TILE, BST_CHECKED);
				tileStr[0] = '1';
			} else {
				CheckDlgButton(hwnd, ID_TILE, BST_UNCHECKED); 
				tileStr[0] = '0';
			}
			RegCreateKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, NULL, REG_OPTION_NON_VOLATILE,
					KEY_ALL_ACCESS, NULL, &root, NULL);
			RegSetValueEx(root, "TileWallpaper", 0, REG_SZ, (unsigned char *)tileStr, sizeof(tileStr));
			RegCloseKey(root);
			break;
		case ID_EXIT:
			SaveOptions();
			TrayProc(hwnd, NIM_DELETE, 0, NULL, "Zap!");
			DestroyIcon(hIcon);
			EndDialog(hwnd, 0);
			return TRUE;
		case ID_HIDE:
			ShowWindow(hwnd, SW_HIDE);
			return TRUE;
		case IDC_ABOUT:
			DialogBox(rb_inst, MAKEINTRESOURCE(IDD_ABOUT), NULL, (DLGPROC)AboutProc);
			return TRUE;
	}
	return FALSE;
}

/* Save struct to Registry */

void SaveOptions(void)
{
	char *key = "Software\\Zap";
	HKEY root;
	DWORD isnew;
	int rc;

	rc = RegCreateKeyEx(HKEY_CURRENT_USER, key, 0, NULL,
			REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &root, &isnew);
	rc = RegSetValueEx(root, "Settings", 0, REG_BINARY, (unsigned char *)&bmp, sizeof(bmp));
	rc = RegCloseKey(root);
}

/* Read struct from Registry */

void GetOptions(void)
{
	char *key = "Software\\Zap";
	HKEY root;
	DWORD isnew;
	unsigned long size, type, rc;

	rc = RegCreateKeyEx(HKEY_CURRENT_USER, key, 0, NULL,
			REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &root, &isnew);
	if (isnew == REG_CREATED_NEW_KEY) {
		bmp.cur_mode = IDC_BMP;
		RegSetValueEx(root, "Settings", 0, REG_BINARY, (unsigned char *)&bmp, sizeof(bmp));
	} else {
		RegQueryValueEx(root, "Settings", NULL, &type, (unsigned char *)&bmp, &size);
	}
	if (size != sizeof(bmp)) {
		RegDeleteKey(root, "Settings");
		RegSetValueEx(root, "Settings", 0, REG_BINARY, (unsigned char *)&bmp, sizeof(bmp));
	}
	RegCloseKey(root);
}

BOOL AboutProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg) {
		case WM_CLOSE:
		case WM_COMMAND:
			if (((LOWORD(wp)) == IDOK) || (msg == WM_CLOSE)) {
				EndDialog(hwnd, TRUE);
				return TRUE;
			}
		break;
	}
	return FALSE;
}

BOOL ParseArgs(void)
{
	BOOL exit = FALSE;
	int i;

	mode = IDC_BMP;
	for (i=1;i<__argc;i++) {
		if (__argv[i][0] == '-') {
			if (__argv[i][1] == 'r') {
				if (i+1==__argc) goto parseError;
				mode = IDC_RANDOM;
				strcpy(bmp.random_dir, __argv[++i]);
			} else if (__argv[i][1] == 'c') {
				if (i+1==__argc) goto parseError;
				mode = IDC_COLOR;
				strcpy(bmp.color, __argv[++i]);
			} else if (__argv[i][1] == 'b') {
				if (i+1==__argc) goto parseError;
				mode = IDC_BMP;
				strcpy(bmp.bitmap, __argv[++i]);
			} else if (__argv[i][1] == 'e') {
				exit = TRUE;
			} else if (__argv[i][1] == 'm') {
				start_state = SW_HIDE;
			}
		}
	}

	if (__argc > 2) {
		switch (mode) {
			case IDC_RANDOM:
				randomBMP();
				break;
			case IDC_COLOR:
				parseColors();
				break;
			case IDC_BMP:
				if (!SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, bmp.bitmap, 0)) {
					sprintf(errMsg, "Error switching bitmap to %s", bmp.bitmap);
					mb(errMsg);
				}
				break;
			default:
				break;
		}
	}
	return exit;

parseError:
	strcpy(errMsg, "Invalid command line argument(s)!");
	mb(errMsg);
	return TRUE;
}

BOOL TrayProc(HWND hwnd, DWORD dwMessage, UINT uID, HICON hIcon, PSTR pszTip)
{
	BOOL res;
	NOTIFYICONDATA nid;

	nid.cbSize				= sizeof(NOTIFYICONDATA);
	nid.hWnd				= hwnd;
	nid.uID					= uID;
	nid.uFlags				= NIF_ICON | NIF_TIP | NIF_MESSAGE;
	nid.uCallbackMessage	= WM_TRAYICON;
	nid.hIcon				= hIcon;
	if (pszTip != NULL && strcmp(pszTip, "")) {
		strcpy(nid.szTip, pszTip);
	} else {
		nid.szTip[0] = '\0';
	}

	res = Shell_NotifyIcon(dwMessage, &nid);
	if (hIcon)
		DestroyIcon(hIcon);
	return res;
}

LRESULT IconDrawItem(LPDRAWITEMSTRUCT lpdi)
{
	HICON hIcon;

	hIcon = (HICON)LoadImage(rb_inst, MAKEINTRESOURCE(lpdi->CtlID), IMAGE_ICON,
		16, 16, 0);
	if (!hIcon) {
		return(FALSE);
	}

	DrawIconEx(lpdi->hDC, lpdi->rcItem.left, lpdi->rcItem.top, hIcon,
		16, 16, 0, NULL, DI_NORMAL);
	return(TRUE);
}
