#define STRICT
#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <shellapi.h>
#include "resource.h"

#define WM_TRAYICON		(WM_APP+100)

char errMsg[248];
HINSTANCE rb_inst;
static HICON hIcon;
int mode;
HMENU pm, pm1;
DWORD start_state = SW_SHOW;

/* This is saved in the Registry */
struct persistent_data {
	char color[7];
	char random_dir[MAX_PATH];
	char bitmap[MAX_PATH];
	int cur_mode;
	int prev_pick;
} bmp;

BOOL CALLBACK MainDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void mb(char *msg);
void parseColors(void);
void randomBMP(void);
int WINAPI WinMain(HINSTANCE hInstance,	HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow);
BOOL CommandHandler(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp);
void SaveOptions(void);
void GetOptions(void);
BOOL AboutProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
BOOL ParseArgs(void);
BOOL TrayProc(HWND hDlg, DWORD dwMessage, UINT uID, HICON hIcon, PSTR pszTip);
LRESULT IconDrawItem(LPDRAWITEMSTRUCT lpdi);
