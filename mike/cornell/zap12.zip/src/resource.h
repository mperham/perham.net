//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Zap.rc
//
#define IDD_MAIN                        101
#define IDI_ICON1                       102
#define IDD_ABOUT                       103
#define IDR_MENU                        104
#define ID_HIDE                         1000
#define IDC_BMP                         1001
#define IDC_COLOR                       1002
#define IDC_RANDOM                      1003
#define IDC_VAL                         1004
#define IDC_VALUE                       1004
#define IDC_ABOUT                       1006
#define IDC_ICON1                       1007
#define IDC_CHANGE                      1008
#define ID_EXIT                         1009
#define IDC_BUTTON1                     1010
#define ID_CHANGE                       40004
#define ID_HELLO_HELLO                  40005
#define ID_TILE                         40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
