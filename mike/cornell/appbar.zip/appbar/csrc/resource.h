//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by appbar-german.rc
//
#define IDD_OPTIONS                     101
#define IDI_APPBAR                      102
#define IDD_ABOUT                       104
#define IDR_MENU                        105
#define IDD_EDIT                        106
#define IDD_NEWAPP                      107
#define IDD_NEWMENU                     108
#define IDI_CAMEL                       110
#define IDI_UP1                         114
#define IDI_DOWN1                       115
#define IDI_DOWN2                       116
#define IDI_UP2                         117
#define IDD_RUN                         123
#define IDC_STAYONTOP                   1000
#define IDC_CHIME                       1001
#define IDC_APPLIST                     1002
#define IDC_WAVNAME                     1003
#define IDC_MENULIST                    1004
#define IDB_NEWMENU                     1007
#define IDB_NEWAPP                      1008
#define IDC_WORKINGDIR                  1009
#define IDC_APPNAME                     1010
#define IDB_DELMENU                     1011
#define IDB_DELAPP                      1012
#define IDC_PARAMETERS                  1013
#define IDC_EXENAME                     1014
#define IDC_MENUNAME                    1015
#define IDB_MENUUP                      1028
#define IDB_MENUDOWN                    1029
#define IDB_APPUP                       1030
#define IDC_BROWSE                      1030
#define IDB_APPDOWN                     1031
#define IDC_FINDWAV                     1031
#define IDC_AUTOHIDE                    1032
#define IDB_SEPARATOR                   1033
#define IDB_TESTWAV                     1034
#define IDC_TESTWAV                     1034
#define IDC_DATE                        1036
#define IDC_MEMORY                      1037
#define IDC_BOTTOM                      1038
#define IDC_TIME                        1039
#define IDC_VDESK                       1040
#define IDC_USER                        1040
#define IDC_NORMAL                      1041
#define IDC_MAX                         1042
#define IDC_MIN                         1043
#define IDC_RUNTEXT                     1044
#define ID_OPTIONS                      40001
#define ID_EDIT                         40004
#define ID_ABOUT                        40005
#define ID_EXITAPPBAR                   40006
#define ID_RUN                          40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        124
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
