<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 *
 * @package    Kohana
 * @author     Kohana Team
 * @copyright  (c) 2007-2009 Kohana Team
 * @license    http://kohanaphp.com/license
 */

class Cache_Exception_Core extends Kohana_Exception {}
// End Kohana User Exception
