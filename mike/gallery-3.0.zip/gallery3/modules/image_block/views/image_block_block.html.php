<?php defined("SYSPATH") or die("No direct script access.") ?>
<div class="g-image-block">
  <a href="<?= $item->url() ?>">
   <?= $item->thumb_img(array("class" => "g-thumbnail")) ?>
  </a>
</div>
