<?php defined("SYSPATH") or die("No direct script access.") ?>
<ul class="g-message-block">
  <li class="g-warning"><?= t("No active sidebar blocks.") ?>
    <br/><a href="<?= url::site("admin/sidebar") ?>"><?= t("Add blocks") ?></a>
  </li>
</ul>
