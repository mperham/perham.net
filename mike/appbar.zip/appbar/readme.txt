AppBar for Windows 95/NT4 v1.02

Don't run appbar.exe under WinNT 3.x.  It won't work very well. :)
Go to the home page to get a WinNT 3.x version (see bottom for URL).

IMPORTANT: MAKE SURE YOU ARE USING THE LATEST VERSION OF APPBAR 
BEFORE YOU E-MAIL ME WITH ANY PROBLEMS!!!

****** Intro ************************************

AppBar is a simple, fast and easy-to-use menuing system for Win32.  Since
this program is a full 32-bit program, it will not run in Windows 3.x. 

My idea behind AppBar was threefold: 1) I wanted a version of FileBar for
OS/2 that ran under Win95 since I found that program incredibly useful; 
2) I wanted to write a menu system for Win95 that was as small as possible
to show that Win32 programs do not have to be 1 MB and have MAPI support
to do something effectively; and 3) I wanted to learn C and the Win32 API
better. 

As it is, AppBar is a visual clone of FileBar (with a few exceptions).  
None of Eric Wolf's code was used in this program however.

****** Command Line Parameters *******************

Usage: appbar.exe [+/-[f filename] [c] [s] [t] [m] [a] [d] [b]] [name]

"Name" represents a user configuration.  If you use this, a new settings
entry is created in the Registry and a new data file, appbar.name, is 
created in the AppBar directory to store the menu items for that user. 
With this, you can have several people use AppBar on the same computer 
while each has their own menus and settings.  This setting overrides all 
other switches. 

	Example: appbar.exe mike

Use (or create) user setting mike in registry and file mike.ab.

Switches

Switches are prefixed by a plus or minus depending on whether you want
to turn on/off that setting.  (yes) means that option is on by default.

	"c" - chime or play a WAV on the hour. (no)
	"s" - stayontop. (yes)
	"t" - display time. (yes)
	"m" - display free memory. (yes)
	"b" - place AppBar at the bottom of the screen. (no)
	"d" - display date. (no)
	"a" - autohide. (yes)
	"f" - use the data file indicated.
		- THE FILENAME MUST COME RIGHT AFTER THIS SWITCH and it
		  doesn't matter if the switch is preceeded by a + or -.

	Example: appbar.exe +s -c +f mydatafile

Turn off the chime, turn on stayontop and use "mydatafile" as the
menu datafile (long filenames are fine and extension doesn't matter).

The only difference between using a user configuration and the switches is
that the switches change the default configuration while using a user
configuration means that any changes to the options are saved to that user
configuration ONLY. 

****** Money ************************************

AppBar is freeware with one exception.  If you are using this on your 
private machine, you do not have to pay me anything to use it.  There are 
no nags and no hidden "features."  If you want to send me a few bucks, 
I won't complain.

HOWEVER, if this program is to be used in a commercial/business 
environment, you have 15 days to try AppBar.  If you like it, I ask that 
you register it for $1 per workstation.  $100 gets you a site license and 
the right to do anything you'd like with the source as long as the 
modified source is not publically released.

Non-profit businesses may use AppBar freely.  The source is still extra
though.

Make checks payable to Mike Perham and send to:

630 Stewart Ave
Ithaca NY 14850 (before Dec 1st, 1997)

4481 Elder Ave
Seal Beach CA 90740 (after)

This program may be freely redistributed as long as it is in its original
archive file and no fee is charged for the program itself.

****** Thanks **********************************

Official AppBar thanks goes to PeopleSoft Inc (http://www.peoplesoft.com),
who hired me as an intern and which was where I worked while writing what 
has become AppBar.  They have a free unlimited license if they want it.

Thanks to Boyd Fjeldsted <bebrblf@business.utah.edu> for a $10 
contribution to the AppBar development fund and his feedback/testing.

Thanks to Kai Schatzl for translating AppBar into German and beta testing.

Thanks to Command Software Systems for site licensing AppBar.

And finally, thanks to all the people who have also sent me money.  It
is appreciated.

****** Administrivia ***************************

E-mail: mperham@cs.cornell.edu
WWW: http://www.cs.cornell.edu/home/mperham/appbar/
AppBar is written in Visual C++ v4.2 in Windows NT v4.0.
