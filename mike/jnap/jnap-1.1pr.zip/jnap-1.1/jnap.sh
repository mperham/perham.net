#!/bin/sh

JAVA=`which java`
if [ "$JAVA" = "" ]; then
	echo java was not found in your PATH.  Please install java 1.2.2 and put
	echo "...path_to_java.../bin" in your PATH.
	exit 0
fi
$JAVA -jar jnap.jar $*
