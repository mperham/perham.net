#!/bin/sh

JAVA=`which java`
if [ "$JAVA" = "" ]; then
	echo java was not found in your PATH.  Please install java 1.2.2 and put
	echo "...path_to_java.../bin" in your PATH.
	exit 0
fi

BIN_DIR=`dirname $JAVA`
JDK_DIR=`dirname $BIN_DIR`
CLASSPATH=$JDK_DIR/lib/rt.jar:./jnap.jar

$JAVA -classpath $CLASSPATH net.perham.jnap.Main $*
