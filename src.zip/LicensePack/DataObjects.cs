using System;
using System.Collections;
using System.Text;
using System.IO;


namespace LicensePack
{
	/// <summary>
	/// A ContactPointType is a definition of further type within a ContactPoint object.
	/// This provides the Power Type pattern of an object having further revision to its 
	/// runtime type without introduction of a new class.
	/// </summary>
	[System.Runtime.Remoting.Metadata.SoapType(XmlNamespace="www.mailframe.net")]
	public enum ContactPointType
	{
		Phone,
		Fax,
		Email,
		Mobile,
		Pager,
		HomePhone
	}

	/// <summary>
	/// Use this enumeration to specify your optional marital status.
	/// </summary>
	[System.Runtime.Remoting.Metadata.SoapType(XmlNamespace="www.mailframe.net")]
	public enum MaritalStatus
	{
		Married,
		Single,
		Divorced,
		Recently_Divorced,
		Unspecified
	}
	/// <summary>
	/// A ContractPoint is an abstract communication address to generically
	/// contain a mail, phone, etc.
	/// ContactPoint is a Power Type that varies its runtime type without changing class.
	/// </summary>
	[Serializable]
	public class ContactPoint 
	{

		public ContactPoint():base(){}

		private ContactPointType _Type = ContactPointType.Phone;
		
		public virtual ContactPointType Type 
		{
			get 
			{
				return _Type;
			}
			set 
			{
				_Type = value;
			}
		}
		private string _Value = "";
		public virtual string Value 
		{
			get 
			{
				return _Value;
			}
			set 
			{
				_Value = value;
			}
		}
	}

	/// <summary>
	/// A Address defines a particular physical location with the US address format.
	/// </summary>
	[Serializable]
	public class Address
	{
		public Address():base(){}
		private string _StreetAddress = "";
		public virtual string StreetAddress 
		{
			get 
			{
				return _StreetAddress;
			}
			set 
			{
				_StreetAddress = value;
			}
		}
		private string _StreetAddressContinued = "";
		public virtual string StreetAddressContinued 
		{
			get 
			{
				return _StreetAddressContinued;
			}
			set 
			{
				_StreetAddressContinued = value;
			}
		}
		private string _City = "";
		public virtual string City 
		{
			get 
			{
				return _City;
			}
			set 
			{
				_City = value;
			}
		}
		private string _State = "";
		public virtual string State 
		{
			get 
			{
				return _State;
			}
			set 
			{
				_State = value;
			}
		}
		private string _Zip = "";
		public virtual string Zip 
		{
			get 
			{
				return _Zip;
			}
			set 
			{
				_Zip = value;
			}
		}
	}

	/// <summary>
	/// Person defines a single individual. Contact and address data is provided
	/// along with basic demographics.
	/// </summary>
	[Serializable]
	public class Person
	{
		public Person() : base()
		{
			ContactPoint pt = new ContactPoint();
			pt.Type = ContactPointType.HomePhone;
			_ContactPoints.Add(pt);
		}

		private Hashtable _properties = new Hashtable();

		public string Comment
		{
			get
			{
				object cmt = _properties["comment"];
				return cmt==null?"":cmt.ToString();
			}
			set
			{
				_properties["comment"] = value;
			}
		}

		public MaritalStatus MaritalStatus
		{
			get
			{
				object cmt = _properties["marital"];
				return cmt==null?MaritalStatus.Unspecified:(MaritalStatus)cmt;
			}
			set
			{
				_properties["marital"] = value;
			}
		}


		public bool Self = false;

		public ContactPoint HomePhone
		{
			get
			{
				foreach (ContactPoint cp in ContactPoints)
					if(cp.Type.Equals(ContactPointType.HomePhone)) return cp;
				return null;
			}
		}


		private string _FirstName = "";
		public virtual string FirstName 
		{
			get 
			{
				return _FirstName;
			}
			set 
			{
				_FirstName = value;
			}
		}
		private string _LastName = "";
		public virtual string LastName 
		{
			get 
			{
				return _LastName;
			}
			set 
			{
				_LastName = value;
			}
		}
		private Address _HomeAddress = new Address();
		public virtual Address HomeAddress 
		{
			get 
			{
				return _HomeAddress;
			}
			set 
			{
				_HomeAddress = value;
			}
		}
		private Address _BusinessAddress = new Address();
		public virtual Address BusinessAddress 
		{
			get 
			{
				return _BusinessAddress;
			}
			set 
			{
				_BusinessAddress = value;
			}
		}
		private DateTime _BirthDate = DateTime.Now;
		public virtual DateTime BirthDate 
		{
			get 
			{
				return _BirthDate;
			}
			set 
			{
				_BirthDate = value;
			}
		}
		private ArrayList _ContactPoints = new ArrayList();
		public virtual ArrayList ContactPoints 
		{
			get 
			{
				return _ContactPoints;
			}
			set 
			{
				_ContactPoints = value;
			}
		}

		public string Name
		{
			get
			{
				return _FirstName + " " + _LastName;
			}
			set
			{
				if(value.IndexOf(",") > 0)
				{
					string[] names = value.Split(',');
					_LastName = names.Length > 0 ? names[0].Trim() : ""; 
					_FirstName = names.Length > 1 ? names[1].Trim() : "";
				}
				else
				{
					string[] names = value.Split(' ');
					_FirstName = names.Length > 0 ? names[0].Trim() : ""; 
					_LastName = names.Length > 1 ? names[1].Trim() : "";
				}
			}
		}
	
		public string PreviewString
		{
			get
			{
				return Name + "\n" + Comment;
			}
		}
		private string _ServiceID = "";
		public virtual string ServiceID 
		{
			get 
			{
				return _ServiceID;
			}
			set 
			{
				_ServiceID = value;
			}
		}

		private string _FriendlyName = "";
		public virtual string FriendlyName 
		{
			get 
			{
				return _FriendlyName;
			}
			set 
			{
				_FriendlyName = value;
			}
		}
		
		protected string _SigninName = "";
		public virtual string SigninName 
		{
			get 
			{
				return _SigninName;
			}
			set 
			{
				_SigninName = value;
			}
		}

		public override bool Equals(object obj)
		{
			Person p = obj as Person;
			if(p != null)
				return p.SigninName.Equals(SigninName);
			else
				return false;
		}

		public override int GetHashCode()
		{
			return SigninName.GetHashCode();
		}


	}

	/// <summary>
	/// Product refers to a specific product offering.
	/// </summary>
	[Serializable]
	public class Product
	{
		public Product()
		{
		}

		public string Name;
		public string Description;
		public string Sku;

		public override bool Equals(object obj)
		{
			Product p = obj as Product;
			if(p!= null)
				return p.Sku.Equals(Sku);
			else 
				return false;
		}

		public override int GetHashCode()
		{
			return Sku.GetHashCode();
		}


	}


	/// <summary>
	/// License is stored by a user and references a product, along with the
	/// number of licenses used and available.
	/// </summary>
	[Serializable]
	public class License
	{
		public License()
		{

		}

		private Product _Product;
		public virtual Product Product 
		{
			get 
			{
				return _Product;
			}
			set 
			{
				_Product = value;
			}
		}

		private Person _Person;
		public virtual Person Person 
		{
			get 
			{
				return _Person;
			}
			set 
			{
				_Person = value;
			}
		}

		private int _LicenseCount;
		public virtual int LicenseCount 
		{
			get 
			{
				return _LicenseCount;
			}
			set 
			{
				_LicenseCount = value;
			}
		}

		private DateTime _IssueDate;
		public virtual DateTime IssueDate 
		{
			get 
			{
				return _IssueDate;
			}
			set 
			{
				_IssueDate = value;
			}
		}

		private DateTime _ExpirationDate = DateTime.MaxValue;
		public virtual DateTime ExpirationDate 
		{
			get 
			{
				return _ExpirationDate;
			}
			set 
			{
				_ExpirationDate = value;
			}
		}

		/// <summary>
		/// This is the number of days remaining in the license.
		/// </summary>
		public int DaysRemaining
		{
			get
			{
				return (ExpirationDate - DateTime.Now).Days;
			}
		}

		/// <summary>
		/// If the license date is set to max value, this is a full perpetual license.
		/// </summary>
		public bool PerpetualLicense
		{
			get
			{
				return ExpirationDate.Year.Equals(DateTime.MaxValue.Year);
			}
		}

		

		private string _LicenseKey = "";
		public virtual string LicenseKey 
		{
			get 
			{
				return _LicenseKey;
			}
			set 
			{
				_LicenseKey = value;
			}
		}

		private string _TransactionCrossReference;
		public virtual string TransactionCrossReference 
		{
			get 
			{
				return _TransactionCrossReference;
			}
			set 
			{
				_TransactionCrossReference = value;
			}
		}

		public override bool Equals(object obj)
		{
			License l = obj as License;
			if(l != null)
				return l.LicenseKey.Equals(LicenseKey) && l.Product.Equals(Product) && l.Person.Equals(Person);
			else
				return false;
		}

		public override int GetHashCode()
		{
			return LicenseKey.GetHashCode();
		}
		public string ToXml()
		{
			System.Runtime.Serialization.Formatters.Soap.SoapFormatter fmt = new System.Runtime.Serialization.Formatters.Soap.SoapFormatter();
			MemoryStream mems = new MemoryStream();	
			fmt.Serialize(mems,this);
			return new UTF8Encoding().GetString(mems.ToArray());
		}

		public static License FromXml(string licenseContent)
		{
			System.Runtime.Serialization.Formatters.Soap.SoapFormatter fmt = new System.Runtime.Serialization.Formatters.Soap.SoapFormatter();
			return fmt.Deserialize(new System.IO.MemoryStream(new System.Text.UTF8Encoding().GetBytes(licenseContent))) as License;
		}


	}

}
