using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace LicensePack
{
	/// <summary>
	/// Summary description for DisintegratorOptions.
	/// </summary>
	public class LicenseDialogForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel1;
		private Infragistics.Win.UltraWinEditors.UltraTextEditor editEmail;
		private Infragistics.Win.UltraWinEditors.UltraTextEditor editLicense;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox imageOK;
		private System.Windows.Forms.PictureBox imageCancel;
		private System.Windows.Forms.Label labelMessage;
		private System.Windows.Forms.LinkLabel linkLabel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LicenseDialogForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();


		}

		public ServiceInterface ServiceInterface;
		public Product Product;

		public string Message
		{
			get
			{
				return labelMessage.Text;
			}
			set
			{
				if(value == null)
					return;
				labelMessage.Text = value;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(LicenseDialogForm));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.imageOK = new System.Windows.Forms.PictureBox();
			this.imageCancel = new System.Windows.Forms.PictureBox();
			this.editEmail = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
			this.editLicense = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.labelMessage = new System.Windows.Forms.Label();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 152);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(128, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Your Email Address:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 216);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(224, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "Your License Key:";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.Controls.Add(this.imageOK);
			this.panel1.Controls.Add(this.imageCancel);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 302);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(304, 40);
			this.panel1.TabIndex = 10;
			// 
			// imageOK
			// 
			this.imageOK.Image = ((System.Drawing.Image)(resources.GetObject("imageOK.Image")));
			this.imageOK.Location = new System.Drawing.Point(128, 8);
			this.imageOK.Name = "imageOK";
			this.imageOK.Size = new System.Drawing.Size(88, 24);
			this.imageOK.TabIndex = 6;
			this.imageOK.TabStop = false;
			this.imageOK.Visible = false;
			this.imageOK.Click += new System.EventHandler(this.imageOK_Click);
			// 
			// imageCancel
			// 
			this.imageCancel.Image = ((System.Drawing.Image)(resources.GetObject("imageCancel.Image")));
			this.imageCancel.Location = new System.Drawing.Point(192, 8);
			this.imageCancel.Name = "imageCancel";
			this.imageCancel.Size = new System.Drawing.Size(104, 24);
			this.imageCancel.TabIndex = 7;
			this.imageCancel.TabStop = false;
			this.imageCancel.Click += new System.EventHandler(this.imageCancel_Click);
			// 
			// editEmail
			// 
			this.editEmail.Location = new System.Drawing.Point(16, 168);
			this.editEmail.Name = "editEmail";
			this.editEmail.Size = new System.Drawing.Size(272, 21);
			this.editEmail.TabIndex = 11;
			this.editEmail.ValueChanged += new System.EventHandler(this.editEmail_ValueChanged);
			// 
			// editLicense
			// 
			this.editLicense.Location = new System.Drawing.Point(16, 240);
			this.editLicense.Name = "editLicense";
			this.editLicense.Size = new System.Drawing.Size(272, 21);
			this.editLicense.TabIndex = 11;
			this.editLicense.ValueChanged += new System.EventHandler(this.editEmail_ValueChanged);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(304, 40);
			this.pictureBox1.TabIndex = 12;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// labelMessage
			// 
			this.labelMessage.Location = new System.Drawing.Point(8, 40);
			this.labelMessage.Name = "labelMessage";
			this.labelMessage.Size = new System.Drawing.Size(288, 104);
			this.labelMessage.TabIndex = 13;
			this.labelMessage.Text = "Before proceeding, you will need to enter your email address and license key. The" +
				" license has been emailed to you.";
			// 
			// linkLabel1
			// 
			this.linkLabel1.Location = new System.Drawing.Point(8, 272);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(272, 24);
			this.linkLabel1.TabIndex = 14;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "Privacy Armor Products";
			this.linkLabel1.Click += new System.EventHandler(this.linkLabel1_Click);
			// 
			// LicenseDialogForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(304, 342);
			this.ControlBox = false;
			this.Controls.Add(this.linkLabel1);
			this.Controls.Add(this.labelMessage);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.editEmail);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.editLicense);
			this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "LicenseDialogForm";
			this.Text = "License Key";
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void domainUpDown1_SelectedItemChanged(object sender, System.EventArgs e)
		{
		
		}

		private void editEmail_ValueChanged(object sender, System.EventArgs e)
		{
			//try to validate and enable the ok button
			Person person = new Person();
			person.SigninName = Email;
			License license = new License();
			license.Product = Product;
			license.LicenseKey = LicenseKey;
			imageOK.Visible = ServiceInterface.ValidateLicense(person,license);
		}

		private void imageCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void imageOK_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void pictureBox1_Click(object sender, System.EventArgs e)
		{
			
		}

		private void linkLabel1_Click(object sender, System.EventArgs e)
		{
			string target = "http://www.privacyarmor.com/ProductsList.aspx?Type=C";
			try
			{
				System.Diagnostics.Process p = new System.Diagnostics.Process();
				System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo("iexplore",target);
				p.StartInfo = psi;
				psi.UseShellExecute = true;
				p.EnableRaisingEvents = false;
				p.Start();
			}
			catch(Exception ex)
			{
			}
		}

		public string Email
		{
			get
			{
				return editEmail.Text;
			}
			set
			{
				editEmail.Text = value;
			}
		}
		public string LicenseKey
		{
			get
			{
				return editLicense.Text;
			}
			set
			{
				editLicense.Text = value;
			}
		}
		}
}
